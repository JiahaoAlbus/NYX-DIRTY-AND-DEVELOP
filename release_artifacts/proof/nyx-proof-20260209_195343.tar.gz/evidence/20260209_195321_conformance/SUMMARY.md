# NYX verify_all PASS

- seed: 123
- run_id_base: conformance
- run_session: conformance-20260209_195321
- timestamp: 20260209_195321
- base_url: http://127.0.0.1:8091
- account_a: acct-4acd0c7d1f1e9ba2 (@af2f6502d)
- account_b: acct-71e46f68f55505df (@b3096c758)

Artifacts:
- verify log: `docs/evidence/20260209_195321_conformance/verify_all/verify.log`
- manifest: `docs/evidence/20260209_195321_conformance/verify_all/manifest.json`
- replay outputs: `docs/evidence/20260209_195321_conformance/verify_all/replay/`

## External integrations (read-only)

- 0x quote: status=200 (`docs/evidence/20260209_195321_conformance/verify_all/integration_0x_quote.json`)
- Jupiter quote: status=200 (`docs/evidence/20260209_195321_conformance/verify_all/integration_jupiter_quote.json`)
- Magic Eden collections: status=unknown (`docs/evidence/20260209_195321_conformance/verify_all/integration_magic_eden_collections.json`)
- Magic Eden listings: skipped
- Magic Eden token: skipped

## Runs (state mutations)

| run_id | state_hash | receipt_hash | fee_total | treasury |
|---|---|---|---:|---|
| `conformance-wallet-faucet-a-nyxt-73` | `f6c1d38128e9fad7032420d9d4495c6743c1d6ba40abbe5d84672f8cf41653a2` | `0fb9eb295af565057d25c3768aa292406404bdf44e94352aaf2acac543a7d7be` | 157 | `testnet-treasury-unconfigured` |
| `conformance-wallet-faucet-b-echo-74` | `bbae49db3bd1fc3aa3519ab4d5e1eaf9b822260ef321c5157ae63ba560f4ef53` | `82f59e23f9f06c4542b5ceba69d7481e6b798196dd9d6ca90d55e2d0b24cf638` | 157 | `testnet-treasury-unconfigured` |
| `conformance-web2-guard-a-75` | `31bf4d07b5fb4e0435c0423438dd6631ae69261602bfe09aeabc6cbd4585e252` | `94ea96a4044c8a44e3f18cf447f53cffa933cacad55dd9f23dd99a4c217585d4` | 437 | `testnet-treasury-unconfigured` |
| `conformance-wallet-transfer-a-to-b-76` | `59a87c4d36dd4f7bfb5ddccbc87063d4b8979ae6cf9a3357893d8de9385125fd` | `44a02c455e33ce45dedfde2ccebba068b3ca1e9c1b97e15a7633011833e77368` | 200 | `testnet-treasury-unconfigured` |
| `conformance-exchange-sell-b-77` | `7990b7071b7ba96fd70f076cac8956221f80a1bf33dbf1519632adb0ad715ae6` | `ed5f8ed61918e3c39e887fb0e2d7e6b65cf94f91d7f0adb4ab47af2b2bf76e96` | 212 | `testnet-treasury-unconfigured` |
| `conformance-exchange-buy-a-78` | `ffc17a715a9059d1b01ded0f3aedb0762d522374e49521a3162cddede8c3bfd6` | `02507b48906a3e43a4210b90279aca343409b29a7d1371eac16a38e7cad0a2c3` | 211 | `testnet-treasury-unconfigured` |
| `conformance-marketplace-publish-b-79` | `e0b2425af98ecc0db7cf7fd04d62d344d89281fe1706666b5d2a57f10c239521` | `8805e87f8d68c81ac4ec375d21ea823b6ef321d3a1168583effab46f097489bf` | 186 | `testnet-treasury-unconfigured` |
| `conformance-marketplace-purchase-a-80` | `6b981c80ee7965ec7224e9581f160b5ca6c951e279fc630858b55ca372880ce7` | `0fb966182ed5f8212357d844f941d73d75c5e121b857ab61d0ab6851933bf2e0` | 189 | `testnet-treasury-unconfigured` |
| `conformance-airdrop-claim-a-trade_1-81` | `511648c5a536f67e4ce1d60091aa78417d079ee6fa72b15f9f0a74b6fccbe6fd` | `295660e67a372444332aa505ad6ceda5d82103bb26763616540a00637a13b864` | 162 | `testnet-treasury-unconfigured` |
| `conformance-airdrop-claim-a-store_1-82` | `292e622065ed2344fd414f201ef4eb4309e9979127549b2cf6870fe1c73daa7f` | `ae932f37384a831611a6a8f12fb09bc134afebb74d483fe010267cbb5a401caa` | 162 | `testnet-treasury-unconfigured` |
| `conformance-chat-dm-a-to-b-83` | `0332f0801d8dda059e1945af8158e87aafd5aa5b0b91db2efa1d374e195c5a7e` | `295b7ec439a941d711e9ebbaf466c14f9018ba6d845fe9a18cae97c4efc35758` | 283 | `testnet-treasury-unconfigured` |
| `conformance-airdrop-claim-a-chat_1-84` | `2372994ac00593de061967470e44dff93e5db0b99c1660bb8a6e4ddf195e3268` | `21e30b4dcc61207504d4caad264f3a71af64bdd16ea68683445296596d49838f` | 161 | `testnet-treasury-unconfigured` |

## Proof export

- proof.zip (account A): `docs/evidence/20260209_195321_conformance/verify_all/proof_acct-4acd0c7d1f1e9ba2.zip`
- sha256: `247da918c3a042f7f37b8dd36e560ce75f4147f5d5361464fb4ff24e248d2490`
