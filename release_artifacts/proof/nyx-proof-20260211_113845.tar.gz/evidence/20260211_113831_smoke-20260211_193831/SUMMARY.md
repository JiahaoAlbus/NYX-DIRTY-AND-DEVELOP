# NYX verify_all PASS

- seed: 123
- run_id_base: smoke-20260211_193831
- run_session: smoke-20260211_193831-20260211_113831
- timestamp: 20260211_113831
- base_url: http://127.0.0.1:8091
- account_a: acct-900bd37940d21062 (@a9b11720b)
- account_b: acct-732f9c552f1fa3db (@b415b77cc)

Artifacts:
- verify log: `docs/evidence/20260211_113831_smoke-20260211_193831/verify_all/verify.log`
- manifest: `docs/evidence/20260211_113831_smoke-20260211_193831/verify_all/manifest.json`
- replay outputs: `docs/evidence/20260211_113831_smoke-20260211_193831/verify_all/replay/`

## External integrations (read-only)

- 0x quote: status=200 (`docs/evidence/20260211_113831_smoke-20260211_193831/verify_all/integration_0x_quote.json`)
- Jupiter quote: status=200 (`docs/evidence/20260211_113831_smoke-20260211_193831/verify_all/integration_jupiter_quote.json`)
- Magic Eden collections: status=200 (`docs/evidence/20260211_113831_smoke-20260211_193831/verify_all/integration_magic_eden_collections.json`)
- Magic Eden listings: status=200 (`docs/evidence/20260211_113831_smoke-20260211_193831/verify_all/integration_magic_eden_listings.json`)
- Magic Eden token: skipped

## Runs (state mutations)

| run_id | state_hash | receipt_hash | fee_total | treasury |
|---|---|---|---:|---|
| `smoke-20260211_193831-wallet-faucet-a-nyxt-1` | `3a06a5da3801465a20cd52e96112186892e2152376bc49115983ad679e638e63` | `91538d61e663e7ce1956e1c5162f626e4161567b5afd71ca345cbb1ba45c0976` | 159 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193831-wallet-faucet-b-echo-2` | `5500637dd3322671274fa98f0f499862c8808225e27c343e54c273419276babe` | `523daa3662225c5d251dd7b2144a78377dee1b94d7b6b37af0bba9af2cfdf4d5` | 159 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193831-web2-guard-a-3` | `d1c16cbe8b863165cec08d61f0e3876d0a3777b69ddda24e896c41ddaca1f670` | `9f0c1d1d49053b18b2ca97e872768c74b4a3a8c9b0194edb3165b5b3c2bff6fb` | 437 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193831-wallet-transfer-a-to-b-4` | `41c36d41e143fa46d7bc1ff23b98422e56dca72b7792ff388d79ac3ad53961db` | `44c40e7434b2ca2c652a5807793cfc13c61c5d19b298507d99bca86983538dc7` | 205 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193831-exchange-sell-b-5` | `81a39f77580855c758df3d651c59ef7279fbb37b6bc4fc7c5181df9d75057496` | `8712572f21e0f1568c918cfb3b88b1986a9e26c6637a381c6b62ab7153583440` | 214 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193831-exchange-buy-a-6` | `b84422efbfc66737a216a0bc7febe59aec38f800f1121fec3e3c42b400be7e47` | `a08d36d9b4f419459209c4b59c75e0ab1503a5290f0748b248389fc6bffbe133` | 213 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193831-marketplace-publish-b-7` | `84a2459f3e8ab07efa20554890ca59461bad619159fe0c9d662fa00ea49253a5` | `a8a3116e21d3c6143d490f0e91cc8e7a2cc36df40816997435d1f92893c96c4b` | 188 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193831-marketplace-purchase-a-8` | `af232e294c4afdf35ce00eeca02f6452d69d84ddfd3808d2cb4f9c748c8ddd26` | `ceea4a0c3ba6e335535c4779e725497441ed72d20b8597cc85864f76a30f9a0e` | 191 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193831-airdrop-claim-a-trade_1-9` | `66696b65126bfd0354c4202ea3ce97c9b87be6041603113ce4f98766cdfa15e9` | `b5bc80afd160e1066cd9237fe5f258a67683b00f1a41e123aac25dd12a45daa6` | 205 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193831-airdrop-claim-a-store_1-10` | `ae5fcb18752d3e1886f66d307eda5e8cee1bfbbdfeda90d4ef82f3a47fce9b14` | `751125ff81605ef3d6899edf350eb2332c3ba65f45b830ae207389eaa85c8200` | 205 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193831-chat-dm-a-to-b-11` | `7311cc6a90470e086e8848035bde2df10f506fa20e0d2d707c9febbbe69b3686` | `05b3e0d8e419eac04561daab7a900ccedf9070b73d6d7d47bbfd033de04e90a1` | 283 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193831-airdrop-claim-a-chat_1-12` | `95863f870751902a439cb7312253b8c5250fc1b177a8d6dceb4f16426c779e96` | `ac9d81fe7321a709ddc6040a6bdf7613d3059452656cf218bd8e2f312658a6e6` | 204 | `testnet-treasury-unconfigured` |

## Proof export

- proof.zip (account A): `docs/evidence/20260211_113831_smoke-20260211_193831/verify_all/proof_acct-900bd37940d21062.zip`
- sha256: `1a469a146281a9e6071bc236c983b9bb09752a51af0972a5a3fdcb7d9c77e1ba`
