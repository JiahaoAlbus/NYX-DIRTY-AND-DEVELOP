# NYX verify_all PASS

- seed: 123
- run_id_base: extreme-testnet
- run_session: extreme-testnet-20260204_015859
- timestamp: 20260204_015859
- base_url: http://127.0.0.1:8091
- account_a: acct-2df0782dcbedf0a9 (@abd846e52)
- account_b: acct-4bb695a889142ab8 (@ba92f6569)

Artifacts:
- verify log: `docs/evidence/20260204_015859_extreme-testnet/verify_all/verify.log`
- manifest: `docs/evidence/20260204_015859_extreme-testnet/verify_all/manifest.json`
- replay outputs: `docs/evidence/20260204_015859_extreme-testnet/verify_all/replay/`

## Runs (state mutations)

| run_id | state_hash | receipt_hash | fee_total | treasury |
|---|---|---|---:|---|
| `extreme-testnet-wallet-faucet-a-nyxt-61` | `0a258cd14dfe7427390e3e2437336207bd40edfc6ec4e1d3487836f0ae7a65fa` | `0e25bab18dedc24e80f88faadf8cc00f3f96820a41158444e140fb83f674b9d2` | 166 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `extreme-testnet-wallet-faucet-b-echo-62` | `8f3efc698c08cefeb19a4becce787798c769b1c4aa1c30caddcfb4608afc4d17` | `fa3f0a91a61c57b62414bf2b4edcc9ad3d849bd35a910f3cf64a33c201527c15` | 166 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `extreme-testnet-wallet-transfer-a-to-b-63` | `ac9243bab90dca1782d948f0ae0ded7adaf661694cf130a39f0a3b5502cc9802` | `3a88b61ff0b5456cead055f7ff1d75904f80bffc0c87ac150b5ae454c6323614` | 202 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `extreme-testnet-exchange-sell-b-64` | `ee3a0085330f99a38ca98a3dc3e9e019a719c2981f2d792db2d4c623f0b1895d` | `e67efaf10e1a76c7cc99cdbf5914b85970c5948196a26b61a2a2efc77269d39b` | 212 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `extreme-testnet-exchange-buy-a-65` | `3faf8e83c290abb6bf78194ae835035c49519c59aba311d0a99698d9c1623970` | `6c3c847f7a9dfa11fd74e60fdb52090187023be151a13547a9a892cfaa923b01` | 211 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `extreme-testnet-marketplace-publish-b-66` | `177d34623424255b867c8fd9c8a406a6dd25bec814668e83a2e61f62daa46c38` | `1369e50b3c88224b0199996e0462298237817ebfee4db62b11dec0bace446b7b` | 186 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `extreme-testnet-marketplace-purchase-a-67` | `913117745dc0dfb4acf79321ac080799f45d863748c744ffbc733b986e961f44` | `ab3c078b6cb530288b0bf3e226772443241ad8152642748cb53e7953e98a471f` | 189 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `extreme-testnet-airdrop-claim-a-store_1-68` | `171ee39d418ddda968e5824f04445795e7e7439a750e57e5784b434e3e4f1290` | `ff639c46e1bd80de5fe768341e5d46bcf45f60fd99386e47c40ce95d1a411d3e` | 223 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `extreme-testnet-chat-dm-a-to-b-69` | `b637a259c98501ec5a8c2f6b87f7330817d34b9d609cc6ce2646396962886aae` | `ec17dbd62396550853043c88fe2291a5156bf61c103d829ab0c7ed5680dcdb32` | 283 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `extreme-testnet-airdrop-claim-a-chat_1-70` | `04056d9274a413d00c0edc2564a721e16b61386b9da5d2a5bed8e87f93188d66` | `bbc1991c6ab9797687135ecf9dcca138bc03b0b6ac305b33191297ef4e23aead` | 214 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |

## Proof export

- proof.zip (account A): `docs/evidence/20260204_015859_extreme-testnet/verify_all/proof_acct-2df0782dcbedf0a9.zip`
- sha256: `bd01cc51709d0407336f14a9dfb589212d89a5c1e4a9159e549cde225bd8382c`
