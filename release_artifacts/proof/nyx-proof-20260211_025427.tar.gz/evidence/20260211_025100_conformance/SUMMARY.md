# NYX verify_all PASS

- seed: 123
- run_id_base: conformance
- run_session: conformance-20260211_025100
- timestamp: 20260211_025100
- base_url: http://127.0.0.1:8091
- account_a: acct-b7e804ee539ff829 (@af5c2238e)
- account_b: acct-ce429ddf47c310d3 (@bc165c92c)

Artifacts:
- verify log: `docs/evidence/20260211_025100_conformance/verify_all/verify.log`
- manifest: `docs/evidence/20260211_025100_conformance/verify_all/manifest.json`
- replay outputs: `docs/evidence/20260211_025100_conformance/verify_all/replay/`

## External integrations (read-only)

- 0x quote: status=200 (`docs/evidence/20260211_025100_conformance/verify_all/integration_0x_quote.json`)
- Jupiter quote: status=200 (`docs/evidence/20260211_025100_conformance/verify_all/integration_jupiter_quote.json`)
- Magic Eden collections: status=200 (`docs/evidence/20260211_025100_conformance/verify_all/integration_magic_eden_collections.json`)
- Magic Eden listings: status=200 (`docs/evidence/20260211_025100_conformance/verify_all/integration_magic_eden_listings.json`)
- Magic Eden token: status=200 (`docs/evidence/20260211_025100_conformance/verify_all/integration_magic_eden_token.json`)

## Runs (state mutations)

| run_id | state_hash | receipt_hash | fee_total | treasury |
|---|---|---|---:|---|
| `conformance-wallet-faucet-a-nyxt-93` | `ae8216dbfadec7c54aa059dfa62c326a84dc38e2278db77ab8b54eddedfbfbf6` | `045ace078b7d22e83ff61641d891004f3c0fda2d8a780020c099c86a914aa276` | 159 | `testnet-treasury-unconfigured` |
| `conformance-wallet-faucet-b-echo-94` | `cd816061d4e5cae6ab3ab827b5f56e233db06aca4f568bb4f5ebffab2db2605e` | `9e6688b43e81a2e8c5f7b0a26e642866db4e2d1285db387771b2838bf2c0640b` | 159 | `testnet-treasury-unconfigured` |
| `conformance-web2-guard-a-95` | `a65750bc7ea2c3525ba22b250b49ef02f7013f6ea0287d43c3105e200d270bd1` | `14199b266de850f488ce5e77665c151429a7acff2129a097d7386ed25c581d36` | 437 | `testnet-treasury-unconfigured` |
| `conformance-wallet-transfer-a-to-b-96` | `fdf0ea6f8f8c349826ca58533bfdb18f6e53ee4e625d9d288f796f37ad149273` | `884ffb123f1dc386dd37817d0158fb308be6182e70b8e040f55da233bf2f3f3b` | 205 | `testnet-treasury-unconfigured` |
| `conformance-exchange-sell-b-97` | `e81bae61d48714978a8f33abb878946e6f118d959f232587ca435f09f622de97` | `ab24bf0b96bf4713fce252486063ed9d96d01a97c9fae935461977913a7088ff` | 214 | `testnet-treasury-unconfigured` |
| `conformance-exchange-buy-a-98` | `d92af92a0a9b950fd17897336d542e516bfeacb405f28226d22838f030b0cd64` | `6a92edbc4513b9bf88105899e102b4a755040cbd600db645ce3662dfa9670ab7` | 213 | `testnet-treasury-unconfigured` |
| `conformance-marketplace-publish-b-99` | `20da67436d9f88788ec2b141641f3dcae84c9563035c7eaf15cfd6bc7ad12b7d` | `f32c70e3658ba0a193d2c34a2e6f9ec6814c5535d9517a31a551dcf64415dfb1` | 188 | `testnet-treasury-unconfigured` |
| `conformance-marketplace-purchase-a-100` | `6c95b400d7f28347bdaa7ed3dfd759921b7a5e52cd75857d9b22518f074f07e0` | `29f6108bc77cb69450cc2ea03f63c0f262fe4ab5ee87f2e6989cf11e92042d20` | 191 | `testnet-treasury-unconfigured` |
| `conformance-airdrop-claim-a-trade_1-101` | `0927ab27445eef0d9a717698b7c767cbacfbc86498b91bed9e43c6043ebd21f4` | `9a46bb14eb8e3fe6dbf8f6a35ad76a9ac9dead1124317caf6aad29f547e3645f` | 205 | `testnet-treasury-unconfigured` |
| `conformance-airdrop-claim-a-store_1-102` | `a2843c989e51b7624700ae7b783f0f4a9ad3c8fd7fbe8235b36a8025c327d450` | `2399e1d596e659a5abf8f7f33149c75e1c1cee46a92c8ed8d7a66c6f91a5a7ea` | 205 | `testnet-treasury-unconfigured` |
| `conformance-chat-dm-a-to-b-103` | `7c56ad8555f366ea213b4b398f203750a8ed065801179f2fb4d8fdea7f826857` | `a54912d22cfc598a7721e9a6b8db6be45f7222a337e6feafcd1f50b0fdaf4c33` | 283 | `testnet-treasury-unconfigured` |
| `conformance-airdrop-claim-a-chat_1-104` | `e673de9ed9804c58b592254d3611b707b4766520d28d25ac712fb5cc91298f0a` | `af0f4f636f2dbe41c17f2358606403974275e94fee16711118161b3899dfe9a7` | 204 | `testnet-treasury-unconfigured` |

## Proof export

- proof.zip (account A): `docs/evidence/20260211_025100_conformance/verify_all/proof_acct-b7e804ee539ff829.zip`
- sha256: `4d1cb244aabf91afdf7d0849386af2fce4620438e5eaaa24fca046872ee8253b`
