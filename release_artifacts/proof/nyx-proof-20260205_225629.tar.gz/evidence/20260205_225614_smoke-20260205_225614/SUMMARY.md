# NYX verify_all PASS

- seed: 123
- run_id_base: smoke-20260205_225614
- run_session: smoke-20260205_225614-20260205_225614
- timestamp: 20260205_225614
- base_url: http://127.0.0.1:8091
- account_a: acct-d3ffbbdc08119cc9 (@ab0b528b0)
- account_b: acct-17e559e993b63bf0 (@b50cc0dc4)

Artifacts:
- verify log: `docs/evidence/20260205_225614_smoke-20260205_225614/verify_all/verify.log`
- manifest: `docs/evidence/20260205_225614_smoke-20260205_225614/verify_all/manifest.json`
- replay outputs: `docs/evidence/20260205_225614_smoke-20260205_225614/verify_all/replay/`

## External integrations (read-only)

- 0x quote: status=200 (`docs/evidence/20260205_225614_smoke-20260205_225614/verify_all/integration_0x_quote.json`)
- Jupiter quote: status=200 (`docs/evidence/20260205_225614_smoke-20260205_225614/verify_all/integration_jupiter_quote.json`)
- Magic Eden collections: status=200 (`docs/evidence/20260205_225614_smoke-20260205_225614/verify_all/integration_magic_eden_collections.json`)
- Magic Eden listings: status=200 (`docs/evidence/20260205_225614_smoke-20260205_225614/verify_all/integration_magic_eden_listings.json`)
- Magic Eden token: skipped

## Runs (state mutations)

| run_id | state_hash | receipt_hash | fee_total | treasury |
|---|---|---|---:|---|
| `smoke-20260205_225614-wallet-faucet-a-nyxt-1` | `7784829476a6689ff88c505c2453b88c05dec307fe3457a85a65ee20493c1f87` | `7e8c369f3ce5af49704df7c5eab569fbf1e05d9df6d25da53fdbcca7f65693d7` | 157 | `testnet-treasury-unconfigured` |
| `smoke-20260205_225614-wallet-faucet-b-echo-2` | `c4d7187b0f462a7a5884ed57ca00bbc92e8f56446528c88c42939c25619492ef` | `a117436771a61f8908e22c1d587bdf7fdc6f2864ec104a24f3ae2e3425d94053` | 157 | `testnet-treasury-unconfigured` |
| `smoke-20260205_225614-web2-guard-a-3` | `e39aa83f74e7e616c6dd0428cb587523f87b1f7b6e805b4785e9e2ec674cd7e1` | `7c694fd96d3ad9a5a670be6b1cc28597e24c30b4bbc1aa222b80e6a853258bed` | 436 | `testnet-treasury-unconfigured` |
| `smoke-20260205_225614-wallet-transfer-a-to-b-4` | `0a28a6c95a7f62e7f582719bf8e18029d6ab204f1cf6f9e78eda3a5fc618f1ac` | `dcf01df39cfd39a89c0863379f9f6f89f141c554fb2ccb59a135238bdd124c64` | 200 | `testnet-treasury-unconfigured` |
| `smoke-20260205_225614-exchange-sell-b-5` | `df17c6721271dfb417b0261a89d4ffb04f0badd4f2a8f7bc354d3b960a13696b` | `307b349037f93ece2d93cfb45841fd26897eb91dcd9ba1c408052d48fa9d17c3` | 212 | `testnet-treasury-unconfigured` |
| `smoke-20260205_225614-exchange-buy-a-6` | `6b23556e3b5d36a117f3376a3225ceff6151760ccbb5ef32d733535c68e06055` | `3f72ad8d6ae1f93fcf17629e9e85a5fb748b7a7b7d65d46b8a808b663d2ac652` | 211 | `testnet-treasury-unconfigured` |
| `smoke-20260205_225614-marketplace-publish-b-7` | `7bf9fd7eca682c4e1c178878cfc04add436a824205ace6e600477ede2be78b4d` | `21994a23b94b8e30dd6d367757b5a61e2f5561371fcb1e7eaf75e9ff0556f87a` | 186 | `testnet-treasury-unconfigured` |
| `smoke-20260205_225614-marketplace-purchase-a-8` | `354c97dc7625f7c81f26e9e24d96e83497b1e37552f7f3f3219b2323190e7336` | `e7bf9be276a6e1e7fd0113f799e40a40428ad8df921e96b0ce1fa4749faabc91` | 189 | `testnet-treasury-unconfigured` |
| `smoke-20260205_225614-airdrop-claim-a-trade_1-9` | `2fd1b5fe82a5eaf9519c0b8f97d174d1d67afc986062b6b7935c103de014fa05` | `4fc8e2d1aadb2af4bd30f97001146fac49fe0874004bf99d2b48496aad935d3e` | 220 | `testnet-treasury-unconfigured` |
| `smoke-20260205_225614-airdrop-claim-a-store_1-10` | `a38cbfcab72b3fddcfe77d73dd92a5104a8b98bbfc26d1db0d4979a6f950f4a9` | `484a5997d030d4c8ce8ec7689538af5d170a2d1e0176dc19d5a77825d79e32e0` | 228 | `testnet-treasury-unconfigured` |
| `smoke-20260205_225614-chat-dm-a-to-b-11` | `38c5447db743ceb5179ca2855e33ecb62ccfc1d02a97d1ff0c52959d9ca1e31a` | `54d554b6baa9cac9b3ab48f53767d4ad43659c75a6674d08d34106590fdbf849` | 283 | `testnet-treasury-unconfigured` |
| `smoke-20260205_225614-airdrop-claim-a-chat_1-12` | `de0272460a6e34965db1e5a22df42c29773f4883177beb25ffd6d1107cadf884` | `97387fc4429d5dbbba853bca3b5afb11c5acf0688574ce628480a75da7411124` | 220 | `testnet-treasury-unconfigured` |

## Proof export

- proof.zip (account A): `docs/evidence/20260205_225614_smoke-20260205_225614/verify_all/proof_acct-d3ffbbdc08119cc9.zip`
- sha256: `2313c27ab8f119e0957858c0878a9b1461b13041cd435a8c6569c4d54cc512da`
