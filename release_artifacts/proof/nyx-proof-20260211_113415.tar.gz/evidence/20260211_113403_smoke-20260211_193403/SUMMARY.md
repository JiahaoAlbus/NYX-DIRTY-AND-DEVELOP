# NYX verify_all PASS

- seed: 123
- run_id_base: smoke-20260211_193403
- run_session: smoke-20260211_193403-20260211_113403
- timestamp: 20260211_113403
- base_url: http://127.0.0.1:8091
- account_a: acct-5ed9fd34687068fb (@a4e0940f5)
- account_b: acct-a9169dba6aabfee7 (@b0dbcc726)

Artifacts:
- verify log: `docs/evidence/20260211_113403_smoke-20260211_193403/verify_all/verify.log`
- manifest: `docs/evidence/20260211_113403_smoke-20260211_193403/verify_all/manifest.json`
- replay outputs: `docs/evidence/20260211_113403_smoke-20260211_193403/verify_all/replay/`

## External integrations (read-only)

- 0x quote: status=200 (`docs/evidence/20260211_113403_smoke-20260211_193403/verify_all/integration_0x_quote.json`)
- Jupiter quote: status=200 (`docs/evidence/20260211_113403_smoke-20260211_193403/verify_all/integration_jupiter_quote.json`)
- Magic Eden collections: status=200 (`docs/evidence/20260211_113403_smoke-20260211_193403/verify_all/integration_magic_eden_collections.json`)
- Magic Eden listings: status=200 (`docs/evidence/20260211_113403_smoke-20260211_193403/verify_all/integration_magic_eden_listings.json`)
- Magic Eden token: skipped

## Runs (state mutations)

| run_id | state_hash | receipt_hash | fee_total | treasury |
|---|---|---|---:|---|
| `smoke-20260211_193403-wallet-faucet-a-nyxt-1` | `4f579a97985427dcce8baead29c2bee44d829d45ceddbf6c7d2e916a6814decf` | `1c5ebd5f558a0fd36fe2ca594ce8e73cdf5472fea056310a24a23422ac11e0ff` | 159 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193403-wallet-faucet-b-echo-2` | `90aab715a4b4083bb37a64dc7b64e01c07a6f9c0a87712200861d9a251705e51` | `3c4cb6ffc7caa731f79d9bc4e451cdf1e5afdb3b3d19fd734a20c4a84956ffde` | 159 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193403-web2-guard-a-3` | `1f658549c9b1dd6eb1e40c432ee37046eeb1cfc954b203ca5d273b620b083abe` | `2443fb878da7fb3178da7198e6960a106f21393b75068de07b8e74ba56354f3c` | 437 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193403-wallet-transfer-a-to-b-4` | `db7adc74ca6b4d66d43cdfc65c82978e3ed214694f8acb35e8d36f65c812eec2` | `86d9c49b95c51ee84900a04b5e598644f952434049b265db009ea4225f245f88` | 205 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193403-exchange-sell-b-5` | `c30c5aa975d7e9152b40cda3c97ed3d9b5528302a9eaf8e712a706760156c2db` | `d6088445f7d40086fa56e585bd3782e1eec0e25070737815e19616c1552b2e89` | 214 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193403-exchange-buy-a-6` | `dc9409c212d3b4b45978882a7b337dfa61b6f48a9580bbb3824343f90f44c36e` | `0c9321b4ba419d323835e89e6731e3c92a366ab9e049adf263752239f8553265` | 213 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193403-marketplace-publish-b-7` | `abf6a91f2285f163328e00d9818312fbf21f2d0ddfb499e7901721758315710e` | `dc45f4ec0b9ecb07ca8991c02cefda7a4788aaed4affdad311d4b6aab66b0890` | 188 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193403-marketplace-purchase-a-8` | `3025ea9fa49e2073039d9be84ff5a47918252d264173e2b6b70ada86d09e434b` | `932acefceb0537a54fca5039cc7f563e7be50be2ad2488e25fc92a4bad438cf1` | 191 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193403-airdrop-claim-a-trade_1-9` | `6aa012abeb44ffddb6bbb499d04474da7befbea6daedf40d33955fc23887c76f` | `3b73818237607a01db13832cfdc9d0bfa13afc4176281da42934c50820b5daa5` | 205 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193403-airdrop-claim-a-store_1-10` | `02507099cb6bc8f1abf1be0e1297968169c73dc841161b113655d3fc8d2696d1` | `521e132a4e4abced93f5598b78a85a1cf4a320c271011be6b2703731fccc7f63` | 205 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193403-chat-dm-a-to-b-11` | `5c59e05bb54735fba561d2869798ed6f462e46535fc1ab3e6afd7990b30e71d2` | `f900ff743cae605472895fb6dc145200379a479e1394ab79dbd5508e3e3ff35a` | 283 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193403-airdrop-claim-a-chat_1-12` | `591b5b55dc16f88c14263c91cc6cd4f5884964b599b441897b895fad59dde88a` | `49f8b532b3ee8b6af5e223203d8da38b666efc86b50dd87c6765242c09b965d8` | 204 | `testnet-treasury-unconfigured` |

## Proof export

- proof.zip (account A): `docs/evidence/20260211_113403_smoke-20260211_193403/verify_all/proof_acct-5ed9fd34687068fb.zip`
- sha256: `d3f141e6829f061b7b2a2f3401b6e13b2eecf98e095e3b7e32af973cdcf6671c`
