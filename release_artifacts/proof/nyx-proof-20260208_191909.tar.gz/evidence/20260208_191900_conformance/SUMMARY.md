# NYX verify_all PASS

- seed: 123
- run_id_base: conformance
- run_session: conformance-20260208_191900
- timestamp: 20260208_191900
- base_url: http://127.0.0.1:8091
- account_a: acct-7b45bfbcfb00a73d (@a9cc6af5a)
- account_b: acct-157b1be438c428cc (@b1d2120b3)

Artifacts:
- verify log: `docs/evidence/20260208_191900_conformance/verify_all/verify.log`
- manifest: `docs/evidence/20260208_191900_conformance/verify_all/manifest.json`
- replay outputs: `docs/evidence/20260208_191900_conformance/verify_all/replay/`

## External integrations (read-only)

- 0x quote: status=200 (`docs/evidence/20260208_191900_conformance/verify_all/integration_0x_quote.json`)
- Jupiter quote: status=200 (`docs/evidence/20260208_191900_conformance/verify_all/integration_jupiter_quote.json`)
- Magic Eden collections: status=200 (`docs/evidence/20260208_191900_conformance/verify_all/integration_magic_eden_collections.json`)
- Magic Eden listings: status=200 (`docs/evidence/20260208_191900_conformance/verify_all/integration_magic_eden_listings.json`)
- Magic Eden token: skipped

## Runs (state mutations)

| run_id | state_hash | receipt_hash | fee_total | treasury |
|---|---|---|---:|---|
| `conformance-wallet-faucet-a-nyxt-49` | `10b9d6bac6d836950cbc7025a8f6b0132063f952803f11c47ae8ad6982991e4c` | `96686d620265ee56a2ff879dfaa0908dc82d32e50d8cceda23087f70c070d350` | 157 | `testnet-treasury-unconfigured` |
| `conformance-wallet-faucet-b-echo-50` | `3c6816b251000b6518a15ba371a95ea627054c78ec6a82d266cea1fe9d6dadbe` | `927154b2307b14ac0680f340c9cf42b412e33f2280bdeedc318032561c12d2df` | 157 | `testnet-treasury-unconfigured` |
| `conformance-web2-guard-a-51` | `01ad3dda2b032d46c94d8e2dc6fac17393af2c921cbaa7ca4e9ac76d51ee5f21` | `a85b6345c100cf1698639b761f101b4d1637a2bf40d39a99ecf9dece5ddd401e` | 437 | `testnet-treasury-unconfigured` |
| `conformance-wallet-transfer-a-to-b-52` | `926251dfb857bfefc1cd3173457a23eda0a258a42401a080c5feb9b52bd3b3a7` | `26dfad3510ad472ce77cfd93bb437bd8c532ed77ef95ffb438bfd95fc7d3f7c7` | 200 | `testnet-treasury-unconfigured` |
| `conformance-exchange-sell-b-53` | `46e5b4216821405bcaa12453c8427d1ece36ccf0ce80ffd895e1d2695cf32af0` | `9e20963d22be5339c0546fb6f6870f372b46cf59c2ac3e319303a23b816d7c25` | 212 | `testnet-treasury-unconfigured` |
| `conformance-exchange-buy-a-54` | `baddea1ce8b271890efb519ccd24f683a83631ce7ae44a19decf3555693f3a86` | `f4070908ddb88962e5ea64841c3e39421649d390b25cecf19b5d4c7f25e2fca8` | 211 | `testnet-treasury-unconfigured` |
| `conformance-marketplace-publish-b-55` | `b73b68979c6e35e3d620e10b89877ce3b4c938e332917d29467b8b96f5edd9c3` | `00d3e3e0698afc4f620877f3d3bcd7f3c5b9e01b9ed9a726cf92656d65564901` | 186 | `testnet-treasury-unconfigured` |
| `conformance-marketplace-purchase-a-56` | `ee81319597225df90d19797496559861baee773d688a29bd8a8a544c2565a634` | `e3621877ff72cdaea198e8717b474d5d75f0cea038b76f6644109b8c6cc4f754` | 189 | `testnet-treasury-unconfigured` |
| `conformance-airdrop-claim-a-trade_1-57` | `aeae46098a336915a525b221d38fb2042d4c461d9011358bb93223b4707cf794` | `209ee8ed9891bf3df04a57248d49a452ca5c6fb278c4fc142f1fa7dc20a79c99` | 162 | `testnet-treasury-unconfigured` |
| `conformance-airdrop-claim-a-store_1-58` | `af3906736f64f007a8b423e51c84a81761330994520ef2b8913efa08a6684e99` | `b142fea58c0395e0d7969dac687d775a7ecdaba95f42cff20d1d2eb86313cf13` | 162 | `testnet-treasury-unconfigured` |
| `conformance-chat-dm-a-to-b-59` | `a8437f2069f30e6099b0f2960d5af85f7125988443e7ea2c030ee773877f2ea5` | `539c65a90d487d7c59956a1d736f3d7b4170c9156201ba4531b3412bc7f28658` | 283 | `testnet-treasury-unconfigured` |
| `conformance-airdrop-claim-a-chat_1-60` | `c9834dec36eb7b91f7de027be444eb103bf5d114967c85d98079d48b36e3a20f` | `3da95e88c95b0d99cc9b52aee23071fb814b230616728259245fd657086de447` | 161 | `testnet-treasury-unconfigured` |

## Proof export

- proof.zip (account A): `docs/evidence/20260208_191900_conformance/verify_all/proof_acct-7b45bfbcfb00a73d.zip`
- sha256: `bc379364e95f94bfeda82f0ae91a0b85468b5be38097526d7cd1acf0e8c6471a`
