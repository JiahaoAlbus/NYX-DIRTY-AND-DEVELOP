# NYX verify_all PASS

- seed: 123
- run_id_base: smoke-20260204_020858
- run_session: smoke-20260204_020858-20260204_020858
- timestamp: 20260204_020858
- base_url: http://127.0.0.1:8091
- account_a: acct-6f8c79387a95cb10 (@a3520de19)
- account_b: acct-08431bf738d3d8d7 (@be20607f1)

Artifacts:
- verify log: `docs/evidence/20260204_020858_smoke-20260204_020858/verify_all/verify.log`
- manifest: `docs/evidence/20260204_020858_smoke-20260204_020858/verify_all/manifest.json`
- replay outputs: `docs/evidence/20260204_020858_smoke-20260204_020858/verify_all/replay/`

## Runs (state mutations)

| run_id | state_hash | receipt_hash | fee_total | treasury |
|---|---|---|---:|---|
| `smoke-20260204_020858-wallet-faucet-a-nyxt-1` | `81d542fe02fb7d4cb879d03e677c0d45bfae8c60323851db49a3da7d1fa19067` | `42e2b5ed6a9d0fb93f7a5618970dc3f93792dbb944b867a8990e28322be7fd9c` | 166 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `smoke-20260204_020858-wallet-faucet-b-echo-2` | `d82bd995509838ec7d2bbd4b45221d5bbe74997945399b894e31d206ffcb0a1c` | `093d3be68da96c9f6a2faaa196490b2070d8cf6553a167ed2002e98c85f83a18` | 166 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `smoke-20260204_020858-wallet-transfer-a-to-b-3` | `ff7269c413fbdbba93cdf506b543453ab3c1ff1ca6f42152a809c01a7ccf26ad` | `c4c42294dfd0142638374d58509f3fb370e49ef2ed8bd2d4a6a95a1b3fd17d60` | 202 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `smoke-20260204_020858-exchange-sell-b-4` | `664dab51f98c2eefce2201a817439bf659c1e18fdbdd1f556ddf90b743992fdc` | `255955865b555c9ddb78d33e25732d5bb43c5a84106adf55e8f53e21f89e72c8` | 212 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `smoke-20260204_020858-exchange-buy-a-5` | `6487e83415a2cc328d598982f8b621ef1de866d4aec71f4eae2e5b160a06d00a` | `fd9bdbf6a466225f0355767d78b456e53d24607e072fb619fb3b930c7cba2a15` | 211 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `smoke-20260204_020858-marketplace-publish-b-6` | `23c72fb60e9ec417eba2297e5abc0a91bdad77c0e091a0f9d96ba56d933e736d` | `4639458c0b410cf60774ac62f77e2f26adfce0011ef798e6eab71a04f0c07352` | 186 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `smoke-20260204_020858-marketplace-purchase-a-7` | `8c8cae3524f86a545836557b217b5102f5acfbbb6234db978bb135b372cb1423` | `1f9389d69137d348ab58799c7332984598e69202ffd45f31eebf507ca3163c75` | 189 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `smoke-20260204_020858-airdrop-claim-a-store_1-8` | `0d8025ce0bc140a6fa8a6304a7ef26dcf16d19548b8f73227eb857557f78fce7` | `b4aab1d8eecb7d8ced3e72e919f65c670c831181679b69c0aba89063f5456c65` | 228 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `smoke-20260204_020858-chat-dm-a-to-b-9` | `cab1b3e09a93f914d6d4e5e0236dc0815b2f807bdbc0e389ba422e83d2c151a8` | `8689c85cc6da4db91446cf8d300f03075d7094bfa65a6ee392b9e9fa646f4c62` | 283 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `smoke-20260204_020858-airdrop-claim-a-chat_1-10` | `4f72ad7914678705a492079f03dab70f24a6fd5c1dffc3a2ebfa9720b4bade3f` | `f240afa4104af9d621012cfa422451b2dca76d2682ac0e25f7c7b5adcf50fbe7` | 219 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |

## Proof export

- proof.zip (account A): `docs/evidence/20260204_020858_smoke-20260204_020858/verify_all/proof_acct-6f8c79387a95cb10.zip`
- sha256: `cf16442565b41a002a299f703fb3705df8cb59dffb3fd3b8d80028058430aa8a`
