# NYX verify_all PASS

- seed: 123
- run_id_base: smoke-20260205_214541
- run_session: smoke-20260205_214541-20260205_214541
- timestamp: 20260205_214541
- base_url: http://127.0.0.1:8091
- account_a: acct-0f64cac55f4ad018 (@aabc4d052)
- account_b: acct-9672b4722ec7b4c3 (@b90a53899)

Artifacts:
- verify log: `docs/evidence/20260205_214541_smoke-20260205_214541/verify_all/verify.log`
- manifest: `docs/evidence/20260205_214541_smoke-20260205_214541/verify_all/manifest.json`
- replay outputs: `docs/evidence/20260205_214541_smoke-20260205_214541/verify_all/replay/`

## External integrations (read-only)

- 0x quote: status=200 (`docs/evidence/20260205_214541_smoke-20260205_214541/verify_all/integration_0x_quote.json`)
- Jupiter quote: status=200 (`docs/evidence/20260205_214541_smoke-20260205_214541/verify_all/integration_jupiter_quote.json`)
- Magic Eden collections: status=200 (`docs/evidence/20260205_214541_smoke-20260205_214541/verify_all/integration_magic_eden_collections.json`)
- Magic Eden listings: status=200 (`docs/evidence/20260205_214541_smoke-20260205_214541/verify_all/integration_magic_eden_listings.json`)
- Magic Eden token: skipped

## Runs (state mutations)

| run_id | state_hash | receipt_hash | fee_total | treasury |
|---|---|---|---:|---|
| `smoke-20260205_214541-wallet-faucet-a-nyxt-1` | `c1b3bf927cd8ee27eed00b4b99137c9cb8b496457af4c89ef35c4040a61ebe4f` | `4a7bdde3c743e7a326ac1ec6e9a451b732b26451269ef2e615f0603fa5ff345a` | 157 | `testnet-treasury-unconfigured` |
| `smoke-20260205_214541-wallet-faucet-b-echo-2` | `824ec627dcce709b563bccf2da9e3b0570c897121d78657905afa8e3e0b89eda` | `68f1727043fd84e63072dfb9ec54b08b65bd931307e996a12838b0a40bf90b31` | 157 | `testnet-treasury-unconfigured` |
| `smoke-20260205_214541-web2-guard-a-3` | `a08ed5e350e675043c8ccd142c69c76cf261f9a2c85a4cf1c83382f88d258b87` | `c556522e15cd153c91fb698aa618701343339ceee018b414ad8cd6d9821a187c` | 436 | `testnet-treasury-unconfigured` |
| `smoke-20260205_214541-wallet-transfer-a-to-b-4` | `d75b6a8cf97a4ef1ebd412200cd9c66087b971d069655fadb5a0b94668175a38` | `7852e7359c969389dd32874e2542c134df0976202508489ec505cf16e186bad9` | 200 | `testnet-treasury-unconfigured` |
| `smoke-20260205_214541-exchange-sell-b-5` | `231ce01fb239becf0017184f3c69e2fab9153cf673f615538c2299b0e1a3dc43` | `88686169ea7987a6aeb21730a5f96bafc90b35e19cc70105a5a349e888006b7b` | 212 | `testnet-treasury-unconfigured` |
| `smoke-20260205_214541-exchange-buy-a-6` | `6615d4bf5e31e9beba072dbca76da7f03fe5b2a9d13cdb43bb21febe46463eb9` | `97b22b2eeaaa8a866568cb30a035c9b60cf96f6a19cfa9c9085f5f7e9f33e9e6` | 211 | `testnet-treasury-unconfigured` |
| `smoke-20260205_214541-marketplace-publish-b-7` | `f2b20019d7f90703e28dfa255b5c3e448af79e2ab3b12d01ed17c210346ee6b0` | `ca32422d18a1d6c87f74e4981813f3ac1218f1387f5805b07c4fa500843e49ab` | 186 | `testnet-treasury-unconfigured` |
| `smoke-20260205_214541-marketplace-purchase-a-8` | `374c35fe2e64b4ad90ac623b9a1c54d6ec80907bec6aee90b29cb5f53ea2cb0f` | `c6e15eb0fbb203dc2f04ca0a23ce6a30eca54abf23803f3501c83e2866c29ee3` | 189 | `testnet-treasury-unconfigured` |
| `smoke-20260205_214541-airdrop-claim-a-trade_1-9` | `3a7cb31be8e1e1a8ac748aea3409c6ef81bd897d22fc383d901e4e2c7f145a61` | `6d497bafbd1e7816d6e0e5495880e6a806a8010b85115a3c648c3d5f3b91009d` | 220 | `testnet-treasury-unconfigured` |
| `smoke-20260205_214541-airdrop-claim-a-store_1-10` | `54d971bb604b42715c4db0d436b56e00b3b4eb3b9b55888cbf68bb30d1dfc53e` | `581e3a7699d0e28f6c2baf3a96a8d8bc17d5be2b9cd380f429b6d82de70d350b` | 228 | `testnet-treasury-unconfigured` |
| `smoke-20260205_214541-chat-dm-a-to-b-11` | `3e4f7c2a959fb908e0ef37e9b39afeb56f82aa9f6eed009b301e240c8a8a537e` | `e26cc2189584d125d06472b8c1c0b5a98f056adc093920d3f4648e8c7beaf0ff` | 283 | `testnet-treasury-unconfigured` |
| `smoke-20260205_214541-airdrop-claim-a-chat_1-12` | `f498279c3a99cc8f6efff6f513a4c1d0bd914a6a14aa69114c547a38b6c3a049` | `2eb6140637747a1a79f2880377794132c355b9fc2da6d47a6de0da32b7877067` | 220 | `testnet-treasury-unconfigured` |

## Proof export

- proof.zip (account A): `docs/evidence/20260205_214541_smoke-20260205_214541/verify_all/proof_acct-0f64cac55f4ad018.zip`
- sha256: `b97d37c9be682b9ede66dcff1d4c239bffe045778507929bd23e6f3a0d32ba41`
