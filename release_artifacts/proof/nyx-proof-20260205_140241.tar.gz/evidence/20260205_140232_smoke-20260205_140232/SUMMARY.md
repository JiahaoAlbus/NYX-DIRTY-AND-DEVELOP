# NYX verify_all PASS

- seed: 123
- run_id_base: smoke-20260205_140232
- run_session: smoke-20260205_140232-20260205_140232
- timestamp: 20260205_140232
- base_url: http://127.0.0.1:8091
- account_a: acct-13e51a89f6512ed0 (@a000c114f)
- account_b: acct-a15fc0b37891c839 (@be68180df)

Artifacts:
- verify log: `docs/evidence/20260205_140232_smoke-20260205_140232/verify_all/verify.log`
- manifest: `docs/evidence/20260205_140232_smoke-20260205_140232/verify_all/manifest.json`
- replay outputs: `docs/evidence/20260205_140232_smoke-20260205_140232/verify_all/replay/`

## External integrations (read-only)

- 0x quote: status=200 (`docs/evidence/20260205_140232_smoke-20260205_140232/verify_all/integration_0x_quote.json`)
- Jupiter quote: status=200 (`docs/evidence/20260205_140232_smoke-20260205_140232/verify_all/integration_jupiter_quote.json`)
- Magic Eden collections: skipped
- Magic Eden listings: skipped
- Magic Eden token: skipped

## Runs (state mutations)

| run_id | state_hash | receipt_hash | fee_total | treasury |
|---|---|---|---:|---|
| `smoke-20260205_140232-wallet-faucet-a-nyxt-1` | `6fd6b64ac6f0d243798cfb989099356801c4bb38ad3ea158437d86527059182c` | `bddb3c02b5c010d241a111483b3cdeed461a1c264174e98e7374e341006eb80d` | 157 | `testnet-treasury-unconfigured` |
| `smoke-20260205_140232-wallet-faucet-b-echo-2` | `76eaafc704fcee8126808542eb8c6f1637ff8bc8d7414b1d020a42929935077d` | `855899776b55f483539eef662279eb86523dc48aba8a03bcde5c9d01819763ce` | 157 | `testnet-treasury-unconfigured` |
| `smoke-20260205_140232-web2-guard-a-3` | `5ea93c103d3373947dc986dc4eb7a4485447ff2826724edb826cdaa44718c87c` | `ec739b6411cf64491331d7fb2a683c4e5bc84dfe0cf5c7b1052c5dd57f2c6613` | 436 | `testnet-treasury-unconfigured` |
| `smoke-20260205_140232-wallet-transfer-a-to-b-4` | `9dfdbde68adbf127b95877453d9444a5ddb91416dcccab9dac0c44abb584fb83` | `3f17a4bb233ad9d1a65005beb4d3de3269e3843fbd994b5c00953469d2612adf` | 200 | `testnet-treasury-unconfigured` |
| `smoke-20260205_140232-exchange-sell-b-5` | `0b84d97c9ebd1db4711df2817ea3e44e1e27d33d4b191d8991c8c67cf984d3f0` | `5cf7d3edcec52571d77c491378d10f342a44b071e9ccde20379d57cc9993616e` | 212 | `testnet-treasury-unconfigured` |
| `smoke-20260205_140232-exchange-buy-a-6` | `a96c0361e83d3f2a2a9a46abaca0a0328e25bcc3070bfafb12817373b71e686d` | `2488193bac9377d211e900aabb8d76f64ba86da200e299d2eb2406a8f949af2f` | 211 | `testnet-treasury-unconfigured` |
| `smoke-20260205_140232-marketplace-publish-b-7` | `9209164ebaaaacf8d361f65f628c6802f9d6d848f522783604443f6dc80ea781` | `19418bd192e1014cd51d2257c5b2ebbf1df1d1acc53c6a80dc16f302eee150b6` | 186 | `testnet-treasury-unconfigured` |
| `smoke-20260205_140232-marketplace-purchase-a-8` | `e1491027312a614958f941c973af5eed8431bba2092a9b1981ab4b4f8ce72aec` | `37486b9037829b4a53502a2fda15f36ab54466d73123f361ff34c404beebe973` | 189 | `testnet-treasury-unconfigured` |
| `smoke-20260205_140232-airdrop-claim-a-trade_1-9` | `1bac8619b0bb74e42e4992dfb4c3fc8469e7d78c3b4a1dc5ae9b8f3ebbbd4d98` | `bd57bdfb80066c505b52e010e523d4fd04bc3e8c4027fe99155521de0af39e72` | 220 | `testnet-treasury-unconfigured` |
| `smoke-20260205_140232-airdrop-claim-a-store_1-10` | `283da81076125beeddbe74dc1a257980a081912cbe32bb38fe3b397c9a58ffa1` | `e94118019a7b9375f929f5d756602ff134c6a98ea2665ec0655df2f80994ca34` | 228 | `testnet-treasury-unconfigured` |
| `smoke-20260205_140232-chat-dm-a-to-b-11` | `70ea023ea2418481a473a934ab3f7e406866005963d4d0862ace7d4cc78178e6` | `aec57b0547159e49ace8e54d30748e551557e884a236f1dcd87cc520ba963370` | 283 | `testnet-treasury-unconfigured` |
| `smoke-20260205_140232-airdrop-claim-a-chat_1-12` | `b44bcb7736fa1b0e793c9fbcc3edcfc2673e456aae4b7800a21c1bc7e4735b76` | `b04355edeb4a01a84e1ad249a8c0268894b0ac22f5ea76b037fcc0f8c53d70bd` | 220 | `testnet-treasury-unconfigured` |

## Proof export

- proof.zip (account A): `docs/evidence/20260205_140232_smoke-20260205_140232/verify_all/proof_acct-13e51a89f6512ed0.zip`
- sha256: `02017c88da606231af11378e859228fd31a8e902467092c2e5d78184bda4415e`
