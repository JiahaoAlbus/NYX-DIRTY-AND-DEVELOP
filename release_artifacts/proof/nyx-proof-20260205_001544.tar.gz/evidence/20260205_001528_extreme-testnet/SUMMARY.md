# NYX verify_all PASS

- seed: 123
- run_id_base: extreme-testnet
- run_session: extreme-testnet-20260205_001528
- timestamp: 20260205_001528
- base_url: http://127.0.0.1:8091
- account_a: acct-0f149a706174fa3f (@a955d3954)
- account_b: acct-391f214a16365800 (@b4963ab30)

Artifacts:
- verify log: `docs/evidence/20260205_001528_extreme-testnet/verify_all/verify.log`
- manifest: `docs/evidence/20260205_001528_extreme-testnet/verify_all/manifest.json`
- replay outputs: `docs/evidence/20260205_001528_extreme-testnet/verify_all/replay/`

## External integrations (read-only)

- 0x quote: skipped
- Jupiter quote: skipped

## Runs (state mutations)

| run_id | state_hash | receipt_hash | fee_total | treasury |
|---|---|---|---:|---|
| `extreme-testnet-wallet-faucet-a-nyxt-99` | `2491850feb1e3b5617e029fd0a14d431eb50a0269e9a51e5216247f74424f890` | `dc7ee55a51e105f534a1d9e72b251d4408a5c85cd4830c3013bf90c8b402ebd6` | 206 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `extreme-testnet-wallet-faucet-b-echo-100` | `5351129480b8fca465bd124c821fd782933ab337e41d17cb5a1a9a5e74ae85e1` | `894b66d52be17cf81c6d263c4f9c3c888c8fbfe3afd1de39cd94faa4c17a0f97` | 166 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `extreme-testnet-web2-guard-a-101` | `326953a094af5166587631bad77646a6e5e7d4a25ee804fe224f28d742dd6da8` | `7b681e58b40dd1bdd464822e84db3c712635a863cfea865cc4f19455240ae06c` | 436 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `extreme-testnet-wallet-transfer-a-to-b-102` | `85150cd0c8d33d9665dc320703064c594c587158776f12a62935bd7ca85ff0b4` | `1e617dd00123f0cb8f92546efe14fa019dbc06f68458793d4816ca5507ad8363` | 202 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `extreme-testnet-exchange-sell-b-103` | `2f9f87bb674a26ac112c447b75aa2be46370144d9c6f65363f0f9ee7e9b7972c` | `97aa513ce28416c0efdc98c5e42ffff3b9acd24a022fba1dc502874ac1829060` | 212 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `extreme-testnet-exchange-buy-a-104` | `184f2483a1ce1ed0b418f5a9b25cc734447cbb467137098a1166f65c66efa6da` | `2d11fa526e4a674ea251eb35c1ada7076228d3a955bf4016db2a3462b74fb913` | 211 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `extreme-testnet-marketplace-publish-b-105` | `09728be3659f69323f43b735b7a4964d8f4577cea30077e9c53ac19cc017b672` | `e3526a616f053c773892c5fedcbf60dacd3b99b530483abbcc37887b621c54b5` | 186 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `extreme-testnet-marketplace-purchase-a-106` | `fa7fe308504ca2ef670b5383abef97dd344584b9eeb2af29ded627fd8207d814` | `588e3b462ba36837381a50808711c15a89c77a9d15a989e5cfb8474e950a52e9` | 189 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `extreme-testnet-airdrop-claim-a-trade_1-107` | `48ed705dec194babffbf07b293b4b467283d75424853d40ae42426b8effdce74` | `d1f972134fce9e96c97fccb136a2a231d480d255438990eaa68dabc4638a7f03` | 216 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `extreme-testnet-airdrop-claim-a-store_1-108` | `ec33449c18b65237bf86d2f4abc87a316065d8b78948c315667275674626ff14` | `b7e6ac2e2487078ff391e43a6d71290e86ee913d391423701d585e6c9f109347` | 224 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `extreme-testnet-chat-dm-a-to-b-109` | `e7935a8f457b1a0e326c8241286d74cab74ac34a9ee4a843c0fb2182905bc3ce` | `a38d68ba637229013cd1bb26968608d2f7f2dac23303a565f7c2446d139272bf` | 283 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `extreme-testnet-airdrop-claim-a-chat_1-110` | `26c7486ecf3b236be4fa6037156bffdc115435a0b528a85e629c24f2790bd78b` | `73e831a3025352c16e1c6e8079aeff908f18a28f498aac19cf544684cbf9ef07` | 215 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |

## Proof export

- proof.zip (account A): `docs/evidence/20260205_001528_extreme-testnet/verify_all/proof_acct-0f149a706174fa3f.zip`
- sha256: `a07ca51299db5b11e06118acf67118081b468dad2d1813adb56e229249fc8f9b`
