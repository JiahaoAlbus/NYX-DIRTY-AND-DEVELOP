# NYX verify_all PASS

- seed: 123
- run_id_base: conformance
- run_session: conformance-20260208_184454
- timestamp: 20260208_184454
- base_url: http://127.0.0.1:8091
- account_a: acct-c27584e2758ec033 (@ad1905063)
- account_b: acct-9bcf720da7da719a (@b1d6a31ed)

Artifacts:
- verify log: `docs/evidence/20260208_184454_conformance/verify_all/verify.log`
- manifest: `docs/evidence/20260208_184454_conformance/verify_all/manifest.json`
- replay outputs: `docs/evidence/20260208_184454_conformance/verify_all/replay/`

## External integrations (read-only)

- 0x quote: status=200 (`docs/evidence/20260208_184454_conformance/verify_all/integration_0x_quote.json`)
- Jupiter quote: status=200 (`docs/evidence/20260208_184454_conformance/verify_all/integration_jupiter_quote.json`)
- Magic Eden collections: status=200 (`docs/evidence/20260208_184454_conformance/verify_all/integration_magic_eden_collections.json`)
- Magic Eden listings: status=200 (`docs/evidence/20260208_184454_conformance/verify_all/integration_magic_eden_listings.json`)
- Magic Eden token: skipped

## Runs (state mutations)

| run_id | state_hash | receipt_hash | fee_total | treasury |
|---|---|---|---:|---|
| `conformance-wallet-faucet-a-nyxt-1` | `9cc339a1a3eaa1d890cbf7bb05b154d00757c79ae82cab0ed966c1dcd444a4a8` | `82cfddfa5826f41d2b506ad3fadfe8b3f9c13181d18406318f4b7a277c64e016` | 157 | `testnet-treasury-unconfigured` |
| `conformance-wallet-faucet-b-echo-2` | `e42d3b7e7df1169bb1c0934979f6fa7195c674e65397d5aff918e66c24cc2b29` | `16f079c3d71b3420ae3f419930c9e6430416de07b8c88a5250a099af78760100` | 157 | `testnet-treasury-unconfigured` |
| `conformance-web2-guard-a-3` | `f002037d37bda96356a9e31e704e21a98611999b37b1a3716330b44c119400a4` | `689901d7d3c60a9c69bb4900395e74b833b92acd738d74c83eff00f04e33bb48` | 436 | `testnet-treasury-unconfigured` |
| `conformance-wallet-transfer-a-to-b-4` | `743477b87db5fe3d753973d116d2e4657a2714dfbb0f09e99a420fdada9c4b5b` | `c1c6b54c05d1473e4f9f20581bd6e3a2c6cc70d5c44930f19887ce95d912e360` | 200 | `testnet-treasury-unconfigured` |
| `conformance-exchange-sell-b-5` | `3120d928909a37e03d645d988c2586e5038d60f01e66c3c6d0376b1f2ed7dfae` | `14fd5a2ef69bfa57feddda87276c8928d99e13022bbd677becef9297f276d9c7` | 212 | `testnet-treasury-unconfigured` |
| `conformance-exchange-buy-a-6` | `cd15e47f542270bd09dd6948a697f851df5e279f010eaeb28398852c6aa230b6` | `9ad47d374cd01ab3d37e7df2c26e64cf1403419ba021f0fd4e606e14ec8955a0` | 211 | `testnet-treasury-unconfigured` |
| `conformance-marketplace-publish-b-7` | `c1b3c70b77f9d5c69669d8d311b80397c1d020e5cdf890806c1feaf2c816f2e5` | `417fac19db1064e8ec7d670eee604fe58b7d3fc150ee84981e43f70af0d5dc18` | 186 | `testnet-treasury-unconfigured` |
| `conformance-marketplace-purchase-a-8` | `309a450a90a806fe625b9e634f5283af43af20e07506e57d7889681b676135fe` | `17c10a9097a1add67b6fba7267f6cf58d7481b9c2d687ac19c6c87013ed098c1` | 189 | `testnet-treasury-unconfigured` |
| `conformance-airdrop-claim-a-trade_1-9` | `88459efe10fe35fc8c3737ef4e87b9101ccc6c3e1cfe9d53534504cae8c241e6` | `b351311d7f1a60a1418fca66147cab14b8cebc6a68002f7c78cb43925acbe64f` | 162 | `testnet-treasury-unconfigured` |
| `conformance-airdrop-claim-a-store_1-10` | `98d6dd56743bfee1b75c3c6782d0b03f6279e21782c10512e4008e51fa305e8f` | `ebbce2f3ebf5e866a5bdb8dc0ce183e83d1e5cf830b6411747d986315f0f9ff3` | 162 | `testnet-treasury-unconfigured` |
| `conformance-chat-dm-a-to-b-11` | `111d57c6adde6d1816e36780b37f248a8b8dbc942aa7178b9560180702622181` | `0c12ecbd49ab673743a3591dbdce01815424b7f5df62e0061911ea5128839fa8` | 283 | `testnet-treasury-unconfigured` |
| `conformance-airdrop-claim-a-chat_1-12` | `531adff8737bf4e4f67f28edc8dc88a1348694a309eb3b77f00be70a05948cd7` | `face62ec4d4b33e757ef9499d0ed8ef7c410e136dd4dfa6d50055b73e1717d36` | 161 | `testnet-treasury-unconfigured` |

## Proof export

- proof.zip (account A): `docs/evidence/20260208_184454_conformance/verify_all/proof_acct-c27584e2758ec033.zip`
- sha256: `467b0b40ad0648b5b8fded07ae6a7b4d587992a5c879cf6f92eba7b6376b1b0e`
