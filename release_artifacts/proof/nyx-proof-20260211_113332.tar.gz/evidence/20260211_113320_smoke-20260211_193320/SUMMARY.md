# NYX verify_all PASS

- seed: 123
- run_id_base: smoke-20260211_193320
- run_session: smoke-20260211_193320-20260211_113320
- timestamp: 20260211_113320
- base_url: http://127.0.0.1:8091
- account_a: acct-75ea7170032b28f5 (@a15a0abb0)
- account_b: acct-39d5829f8d759f74 (@b887dd6e0)

Artifacts:
- verify log: `docs/evidence/20260211_113320_smoke-20260211_193320/verify_all/verify.log`
- manifest: `docs/evidence/20260211_113320_smoke-20260211_193320/verify_all/manifest.json`
- replay outputs: `docs/evidence/20260211_113320_smoke-20260211_193320/verify_all/replay/`

## External integrations (read-only)

- 0x quote: status=200 (`docs/evidence/20260211_113320_smoke-20260211_193320/verify_all/integration_0x_quote.json`)
- Jupiter quote: status=200 (`docs/evidence/20260211_113320_smoke-20260211_193320/verify_all/integration_jupiter_quote.json`)
- Magic Eden collections: status=200 (`docs/evidence/20260211_113320_smoke-20260211_193320/verify_all/integration_magic_eden_collections.json`)
- Magic Eden listings: status=200 (`docs/evidence/20260211_113320_smoke-20260211_193320/verify_all/integration_magic_eden_listings.json`)
- Magic Eden token: skipped

## Runs (state mutations)

| run_id | state_hash | receipt_hash | fee_total | treasury |
|---|---|---|---:|---|
| `smoke-20260211_193320-wallet-faucet-a-nyxt-1` | `a35143e28e8e10d64719912090a4b0797f5a13b032ad9bff3defc8d310073e59` | `c2d03192a9870064ac41d1ee0bb40837e2bef9e3f104ab9af05c20aefd55c6b7` | 159 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193320-wallet-faucet-b-echo-2` | `0129fd3f4a87c6a40cf70ef7e9e4bbddeabd2e04202db8a725b842e7857d1fec` | `843a2813064927f85b7db089657e0553f3de3b13b51b706fd20c1d935e4ec6d1` | 159 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193320-web2-guard-a-3` | `31bf4d07b5fb4e0435c0423438dd6631ae69261602bfe09aeabc6cbd4585e252` | `94ea96a4044c8a44e3f18cf447f53cffa933cacad55dd9f23dd99a4c217585d4` | 437 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193320-wallet-transfer-a-to-b-4` | `86383feaa36c2ebfa77cbfa7de5f8869082388d375532791c14cf672b005ab71` | `c6dcd31faa7ba43a045256f07717b2a7674b47e007b08d1457231f842da4da0b` | 205 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193320-exchange-sell-b-5` | `fe45cae0296e15cae669463b24ad08e550a9f6862d934b3961c44854aefc5dce` | `d6db1b1b4c4d1bca6c948731543d1284778f86d58f30bcdfcd9edd662050092a` | 214 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193320-exchange-buy-a-6` | `6941c5e4ebf2ed00e76944fec343afca15adb2fcbc6bc350d300627e580c8a21` | `95fe5a798ed7a7209df5b438b820630591ce30ec8981200f38b029c8c5b21167` | 213 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193320-marketplace-publish-b-7` | `99ca688271a24b4664e3b74b3c17622cf848072135243c4522bb8f47bc7622f1` | `25ec266fb535609c6d3904c30ef95b3fefca0ae4586bf57a05615c5d64099687` | 188 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193320-marketplace-purchase-a-8` | `8962ccdbdcc49eb7007476eb3763c697d53221e199ebd79d546bd4e7b3b9435e` | `04bae70c18b5e816babfd5a4cd38a26f1f390da4776c266b94ba59e09d93e0ee` | 191 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193320-airdrop-claim-a-trade_1-9` | `4c44ccceffdf1ae06f125e8e50e80b4234fda0e1171ee7b9d5cb5560aa518e0d` | `d6bc2c090daf9a4d80cddea5d2ebf56cc6dca3bee8fac5d19ca0ae985207cd8d` | 205 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193320-airdrop-claim-a-store_1-10` | `823a1d2c65ce59fbdafbe1bf0c9686fc46584bdbc624040046bad3bdb97792fa` | `e812f124aca1c92cd28651b1f4ee7e78f46561942b37f8801cc40a950c8b26da` | 205 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193320-chat-dm-a-to-b-11` | `8a9d1b18cbe81752588bebb20b789cbc72ab16dfc085c5f2dc50efb040d6bbc2` | `c5c4e04955e963cf5268664409b5f62e0a681c1c32973e197272eb86b8880786` | 283 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193320-airdrop-claim-a-chat_1-12` | `7ebea721126758fe55591b746c031d22c47512efa871cc936fa0e99269707d82` | `df47fecd535778aed32e10a8bf5bc67fd3a6af732cb4d2b8f4a90439b8fad8d5` | 204 | `testnet-treasury-unconfigured` |

## Proof export

- proof.zip (account A): `docs/evidence/20260211_113320_smoke-20260211_193320/verify_all/proof_acct-75ea7170032b28f5.zip`
- sha256: `28dd21fd4dfde8a83c416d1d2d603ce81a993aa1068427e2fce84f71b0c20f63`
