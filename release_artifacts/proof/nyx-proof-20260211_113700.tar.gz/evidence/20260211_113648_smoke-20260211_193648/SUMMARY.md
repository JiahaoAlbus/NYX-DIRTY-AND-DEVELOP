# NYX verify_all PASS

- seed: 123
- run_id_base: smoke-20260211_193648
- run_session: smoke-20260211_193648-20260211_113648
- timestamp: 20260211_113648
- base_url: http://127.0.0.1:8091
- account_a: acct-ae80d92c25054b74 (@a054216fe)
- account_b: acct-59728f69cdb9b0df (@bb4fc87e3)

Artifacts:
- verify log: `docs/evidence/20260211_113648_smoke-20260211_193648/verify_all/verify.log`
- manifest: `docs/evidence/20260211_113648_smoke-20260211_193648/verify_all/manifest.json`
- replay outputs: `docs/evidence/20260211_113648_smoke-20260211_193648/verify_all/replay/`

## External integrations (read-only)

- 0x quote: status=200 (`docs/evidence/20260211_113648_smoke-20260211_193648/verify_all/integration_0x_quote.json`)
- Jupiter quote: status=200 (`docs/evidence/20260211_113648_smoke-20260211_193648/verify_all/integration_jupiter_quote.json`)
- Magic Eden collections: status=200 (`docs/evidence/20260211_113648_smoke-20260211_193648/verify_all/integration_magic_eden_collections.json`)
- Magic Eden listings: status=200 (`docs/evidence/20260211_113648_smoke-20260211_193648/verify_all/integration_magic_eden_listings.json`)
- Magic Eden token: skipped

## Runs (state mutations)

| run_id | state_hash | receipt_hash | fee_total | treasury |
|---|---|---|---:|---|
| `smoke-20260211_193648-wallet-faucet-a-nyxt-1` | `d21772c3971220c3164d11fc4091f1c4e98a8ac254485dd8f6055fd4b17dd74d` | `a50646db2494dae6a47aacc1e2d900b1127bc7b742f2501db1d50ebe1ee27757` | 159 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193648-wallet-faucet-b-echo-2` | `05592444a67fd4d2655a27a421f8083900662863df265c546e1571ccd072e5b9` | `b0713f4aceac2df8bdb50a9f154b736a33b48123a3695f769728c5ebdb5daf1e` | 159 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193648-web2-guard-a-3` | `7c0e911638c6183ff8586a787c1b58f6cd0a63cc8e49e24a9626ac00a989cbef` | `432dc3b4f544f5b6a935b0c770c3ba8fcfc701e3190bc0ac9bb4b3851077733b` | 437 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193648-wallet-transfer-a-to-b-4` | `91fb9b2342c46e1da72eb2f03a879cb866a673129bd832e7eb01b9600e6dd8a1` | `629d22255be4c1924070d29be4bc8d513f359a45259c53ccb84d7669134f4c07` | 205 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193648-exchange-sell-b-5` | `0f74a0bc37b244f2f2dd5f1f44cfea937cd50ff63b5de2ba6ea93f4e2e7f5ba6` | `80349f8b2108a7d12abcba5ccaeaf9556b9785996aa002b3b728caf5bbd066b9` | 214 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193648-exchange-buy-a-6` | `17672decf4a2af7a44a5f203f74dd8b761242de90ffbac83dc1e60f59e816ece` | `5877ef98adbbca24cc0c8e206d13d3a919757cc2e903297fedfa3c6efdb7a702` | 213 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193648-marketplace-publish-b-7` | `ca44d58128acd75178d376f1434c0c03c45a088d0e1ba6ddba596a3f98d25bc4` | `539501d09a99e53cc5506de8d9e8c9c7cdf9d8677f993977c51217f154e5deb4` | 188 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193648-marketplace-purchase-a-8` | `effa9052cd6500497b22168f75e1767c456c745d242d6d10118d5f6d7182a9e1` | `1696eeb7bfc8cb89949c897bf5c5a32bebc6cac639054d411845a5229c0a35c7` | 191 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193648-airdrop-claim-a-trade_1-9` | `0dea55b21ca867ed601ca8f7c18325731b60654d66c393be6aabaf57282ff872` | `810556df9d8ba9d4bd622b17a2b9e29b4cb2f57bfae3842d13979970c1c9797d` | 205 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193648-airdrop-claim-a-store_1-10` | `aff118fcba719a074ce5083e02009a2ea8c073539f6a0e90a076680b9d5a154e` | `54ce66cbd174b9bcc8ffff6844daaf1d8f35ba627c179e41802945b73bc97c11` | 205 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193648-chat-dm-a-to-b-11` | `7cc314ddd849755b84af16d7d5277da9dfad48361a5c981bd7d8cdd4f96664fa` | `12fab19439d53e2ca374968b06a617b3fde6abc7dbbe71d8ae556dbca235fb93` | 283 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193648-airdrop-claim-a-chat_1-12` | `24032ea390cda8fe36ef961606dc6be5dedad4594b051ef2ab53ccca014e1eb6` | `3b714a92f934469d39dfa9279c7a5ae3772777d9daa4867b33964471266c0d16` | 204 | `testnet-treasury-unconfigured` |

## Proof export

- proof.zip (account A): `docs/evidence/20260211_113648_smoke-20260211_193648/verify_all/proof_acct-ae80d92c25054b74.zip`
- sha256: `2ecec1f313dd9ab0d57bf9096aa68fd9fe0e13262e2c09e7465b7fc8967fc0c9`
