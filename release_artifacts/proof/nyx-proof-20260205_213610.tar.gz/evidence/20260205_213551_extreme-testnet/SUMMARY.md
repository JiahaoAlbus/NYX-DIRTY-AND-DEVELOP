# NYX verify_all PASS

- seed: 123
- run_id_base: extreme-testnet
- run_session: extreme-testnet-20260205_213551
- timestamp: 20260205_213551
- base_url: http://127.0.0.1:8091
- account_a: acct-786d4f1e4b164185 (@afc149bc5)
- account_b: acct-6d6ca5a1ca01d0b0 (@bf23bc073)

Artifacts:
- verify log: `docs/evidence/20260205_213551_extreme-testnet/verify_all/verify.log`
- manifest: `docs/evidence/20260205_213551_extreme-testnet/verify_all/manifest.json`
- replay outputs: `docs/evidence/20260205_213551_extreme-testnet/verify_all/replay/`

## External integrations (read-only)

- 0x quote: status=200 (`docs/evidence/20260205_213551_extreme-testnet/verify_all/integration_0x_quote.json`)
- Jupiter quote: status=200 (`docs/evidence/20260205_213551_extreme-testnet/verify_all/integration_jupiter_quote.json`)
- Magic Eden collections: status=200 (`docs/evidence/20260205_213551_extreme-testnet/verify_all/integration_magic_eden_collections.json`)
- Magic Eden listings: status=200 (`docs/evidence/20260205_213551_extreme-testnet/verify_all/integration_magic_eden_listings.json`)
- Magic Eden token: skipped

## Runs (state mutations)

| run_id | state_hash | receipt_hash | fee_total | treasury |
|---|---|---|---:|---|
| `extreme-testnet-wallet-faucet-a-nyxt-135` | `b7342112f6bc22df0c9aed32be11e5cd6724cf2939c0b1d288877141bb8b2118` | `3da952771e285c26465bb5a26dc0f4181f1b945fbaa2fc5886954c8ccb411307` | 157 | `testnet-treasury-unconfigured` |
| `extreme-testnet-wallet-faucet-b-echo-136` | `32d0e95d173b52f779033e282e3c04eb06cb7a378d3d9e0e9ae89f358ae55576` | `ed91d23a405c175e7cde97feff6aada4d1f52e0ec2bc18a8b42a09c859a22006` | 157 | `testnet-treasury-unconfigured` |
| `extreme-testnet-web2-guard-a-137` | `8a3c9f4f0d2780c56c5384d8915b89d0fcd4715755c735924a66d55149426fda` | `ff453a74ca7e95673b393e473a6be9ac079948e8cf45966db2f04d9edfbeccef` | 436 | `testnet-treasury-unconfigured` |
| `extreme-testnet-wallet-transfer-a-to-b-138` | `ee1d0fa7d12efff1fd12eb62a473142a791a9ee768300ba014666d985a10091c` | `f89bac907e60ae188b5d37401f1fe19ec508393f149775987cf251b799cb7dbd` | 200 | `testnet-treasury-unconfigured` |
| `extreme-testnet-exchange-sell-b-139` | `d7e3401980cbd65989e9f5c5375dfca174490093bbced16d3b5796a31917d52b` | `72810b6c41c6d9fd2ae713ff3af66514465e05c9a58c02d6b5205dbbc147be4b` | 212 | `testnet-treasury-unconfigured` |
| `extreme-testnet-exchange-buy-a-140` | `88f9380899658b1d2fb254a9dd1dbac116e5fa8fd7c89f6188c12bf31d065a5d` | `233c1a2fe6171cfbeba1826f1835a78a7ff0b3f1ac48b017b52b4bff0e8331b0` | 211 | `testnet-treasury-unconfigured` |
| `extreme-testnet-marketplace-publish-b-141` | `988d67939e7d7e287b9f06e11452b78edccc4d97c991f85e0d7d06c8aa822920` | `3e560c857ed5cbf8738e362d1b528d39e1f203561897777d07a83b03a56e3852` | 186 | `testnet-treasury-unconfigured` |
| `extreme-testnet-marketplace-purchase-a-142` | `58bb0aff46bfe2601889eff0db54239893280b8e51d4e1bd040756ae73791a77` | `64a2975fbb5ba06b4c0d0dc16704ae838fbb536f0416faac36d4b19252fd7d9b` | 189 | `testnet-treasury-unconfigured` |
| `extreme-testnet-airdrop-claim-a-trade_1-143` | `42f3fa2cf0145db6035712753d9363906b003c4008f4b60dcb8ac22609907925` | `248ad9a98c4cb5649eed4dacdc82f748b8e129ba44521a75b7711382c5e68daf` | 216 | `testnet-treasury-unconfigured` |
| `extreme-testnet-airdrop-claim-a-store_1-144` | `5e3ac0908c2d773b9efdf04e601e15817604b88104f754c4a5f0592ec4a1daeb` | `3e95bbe14a3c068b7f96c6cebc8fee49c5b1e598e8d7949c1ab6dddeb8093275` | 224 | `testnet-treasury-unconfigured` |
| `extreme-testnet-chat-dm-a-to-b-145` | `835df01615f94ed11eb53ab1b46e99e975055d07d799099ba9a57af148d59bb5` | `3dd2f60788ff1a6e9116feba6dbcb7ef0d66d8fd7f58219e303d120d7ab25cf6` | 283 | `testnet-treasury-unconfigured` |
| `extreme-testnet-airdrop-claim-a-chat_1-146` | `17a6f22e05a866e1c6fe140ca2327f6e4a1b02648cb17594ae8a499330f9a314` | `242758b73387177d771d9423d9258e7c4522cedd38af736c46dc01e01ae2a4b9` | 215 | `testnet-treasury-unconfigured` |

## Proof export

- proof.zip (account A): `docs/evidence/20260205_213551_extreme-testnet/verify_all/proof_acct-786d4f1e4b164185.zip`
- sha256: `495b2e52678e615b843f3adfef4cbfe930d14a162cf8436070f7e6daaea64663`
