# NYX verify_all PASS

- seed: 123
- run_id_base: smoke-20260211_193448
- run_session: smoke-20260211_193448-20260211_113448
- timestamp: 20260211_113448
- base_url: http://127.0.0.1:8091
- account_a: acct-714315c7f287cf21 (@a545eafa1)
- account_b: acct-52795db312817fdc (@b7e25d02f)

Artifacts:
- verify log: `docs/evidence/20260211_113448_smoke-20260211_193448/verify_all/verify.log`
- manifest: `docs/evidence/20260211_113448_smoke-20260211_193448/verify_all/manifest.json`
- replay outputs: `docs/evidence/20260211_113448_smoke-20260211_193448/verify_all/replay/`

## External integrations (read-only)

- 0x quote: status=200 (`docs/evidence/20260211_113448_smoke-20260211_193448/verify_all/integration_0x_quote.json`)
- Jupiter quote: status=200 (`docs/evidence/20260211_113448_smoke-20260211_193448/verify_all/integration_jupiter_quote.json`)
- Magic Eden collections: status=200 (`docs/evidence/20260211_113448_smoke-20260211_193448/verify_all/integration_magic_eden_collections.json`)
- Magic Eden listings: status=200 (`docs/evidence/20260211_113448_smoke-20260211_193448/verify_all/integration_magic_eden_listings.json`)
- Magic Eden token: skipped

## Runs (state mutations)

| run_id | state_hash | receipt_hash | fee_total | treasury |
|---|---|---|---:|---|
| `smoke-20260211_193448-wallet-faucet-a-nyxt-1` | `e2148fe667b9c0398fe64c897af760e1b152be1c34dc38c4ad95b5c00e2e4942` | `44454a82480ce1c5d04d458e86143c7988fa33b70ed9a3835088dc73182358d6` | 159 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193448-wallet-faucet-b-echo-2` | `090fba6c04b1e3d63743c446b487a0372acb75e8e4f603ba236b8f31aa7cb268` | `50222cf08e90db5f13e0709b7feafb43111b6099b082f842dc16191a78c127fe` | 159 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193448-web2-guard-a-3` | `1f658549c9b1dd6eb1e40c432ee37046eeb1cfc954b203ca5d273b620b083abe` | `2443fb878da7fb3178da7198e6960a106f21393b75068de07b8e74ba56354f3c` | 437 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193448-wallet-transfer-a-to-b-4` | `16c111dac85156f6c8091b12e7d79d759688b038b42b1c2612fe1f1687add029` | `1d2f162fddf5b916d42f222b5dfae1f360e2f185ca8a17fac37e46ecff142f5d` | 205 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193448-exchange-sell-b-5` | `41a09639d0ae0de8e560747f670186077554525a5b0cf4e932bde060a140b8be` | `b8bbd6cb99587aa44348ba23e7dcf9e852b2cd7c105af0cca933090edbbff515` | 214 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193448-exchange-buy-a-6` | `92f08e64e8e22f80505472be7228f148af998b355759bd1a5f8d7479263dfb0b` | `27443d0316981c9c5b347b54faf3a9fdd3eff39dd5e08443e77d08f61eacac34` | 213 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193448-marketplace-publish-b-7` | `b5fc78ed4d881175a657d97192a8d337b67a0d0af150bc2a233e7bb265f7cc77` | `c3d7f41fd6abafdaead00e097585fdb2c7b2f5665e74a305293d2b3e262077f8` | 188 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193448-marketplace-purchase-a-8` | `5c6986bdee841f2b804e6b8daff2e9b66f4c0a60e6021a8dcd3f9e1200c573ea` | `48c31ed92880e68383b691f0af105c74056862372fbac805eb778f3ea3a2b971` | 191 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193448-airdrop-claim-a-trade_1-9` | `ebbae18ee8122425628086614356c3d485636cb057b3b15cb12193d77d72f1a6` | `717b957caff885ce7776ca7a6390de1b78428cf10ce292fb56d1b15c6aeabe49` | 205 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193448-airdrop-claim-a-store_1-10` | `f27a8acee4358d029cb0110f0ed7789d4acdf2e7d534379e1379b5aa6b366f94` | `ed01b03ef55da58816f93766113c781a9a47f703c8f824966c25a4da8bb88c6a` | 205 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193448-chat-dm-a-to-b-11` | `a20297fa959eb24d0fca4e75d42839e79aa9ebfc61896bf20c65ff14999c3585` | `b9c58b292ad990c4c2e3d2a0d604171f0bf906e1c8178805de6ac7b97c7521bd` | 283 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193448-airdrop-claim-a-chat_1-12` | `e658bee01db4988ac2645e4b1808065a37d3590c87da24d05726d9c63fc8a2b1` | `4b7607546cfec8e39c2bc83de33510f5edd9ede642b9f0fa9818736b0253657f` | 204 | `testnet-treasury-unconfigured` |

## Proof export

- proof.zip (account A): `docs/evidence/20260211_113448_smoke-20260211_193448/verify_all/proof_acct-714315c7f287cf21.zip`
- sha256: `b9f3876c176e411bb4ec25c628e92f51b5ab585c328b73c856ae7d3a2c624c0d`
