# NYX verify_all PASS

- seed: 123
- run_id_base: extreme-testnet
- run_session: extreme-testnet-20260211_195839
- timestamp: 20260211_195839
- base_url: http://127.0.0.1:8091
- account_a: acct-39fc1ab6ffe804ce (@a73994fcf)
- account_b: acct-502a5afb8659e97a (@bbf188293)

Artifacts:
- verify log: `docs/evidence/20260211_195839_extreme-testnet/verify_all/verify.log`
- manifest: `docs/evidence/20260211_195839_extreme-testnet/verify_all/manifest.json`
- replay outputs: `docs/evidence/20260211_195839_extreme-testnet/verify_all/replay/`

## External integrations (read-only)

- 0x quote: status=200 (`docs/evidence/20260211_195839_extreme-testnet/verify_all/integration_0x_quote.json`)
- Jupiter quote: status=unknown (`docs/evidence/20260211_195839_extreme-testnet/verify_all/integration_jupiter_quote.json`)
- Magic Eden collections: status=unknown (`docs/evidence/20260211_195839_extreme-testnet/verify_all/integration_magic_eden_collections.json`)
- Magic Eden listings: skipped
- Magic Eden token: skipped

## Runs (state mutations)

| run_id | state_hash | receipt_hash | fee_total | treasury |
|---|---|---|---:|---|
| `extreme-testnet-wallet-faucet-a-nyxt-159` | `6ecc4bffc0e25d1105d9eec4da022f791d1d401d1c5df650f6ac2fd47aaf9d97` | `a54e6661b60599a76e24a6f95f49da8ae68b08dce013518e2470f2590589f9db` | 159 | `testnet-treasury-unconfigured` |
| `extreme-testnet-wallet-faucet-b-echo-160` | `3a7b7aa36ab4efe06ca1a7f434ed43bcbfc5e11a2f5cf26037b9989a4ae8b665` | `9655dcea0b3f590adeca9197ff8ee2f8621ba2c6e0cbd184f2cc97528532064c` | 159 | `testnet-treasury-unconfigured` |
| `extreme-testnet-web2-guard-a-161` | `a65750bc7ea2c3525ba22b250b49ef02f7013f6ea0287d43c3105e200d270bd1` | `14199b266de850f488ce5e77665c151429a7acff2129a097d7386ed25c581d36` | 437 | `testnet-treasury-unconfigured` |
| `extreme-testnet-wallet-transfer-a-to-b-162` | `51747875498b64e8639e7a2dc7efb67ad9db99a8c268378201c4a3cacb4153de` | `66c5101cfefd5b7a3bd7804aa014055ca2ed8a4f44493d59bd878851b4b61276` | 205 | `testnet-treasury-unconfigured` |
| `extreme-testnet-exchange-sell-b-163` | `5ce9759e4f54331f48659d79d094512a0d77f298aeb744fe87c4faaf8e2b1900` | `848bb0096be6575c0d45b18af7aaf54ea73f81cf82dd271f0d42d8af9aa7c0be` | 214 | `testnet-treasury-unconfigured` |
| `extreme-testnet-exchange-buy-a-164` | `06fa8876ff75ce002a62be0e85ec06ffe3b8164ce086da58e8301c6a20150180` | `43cc0de0a16db0c660162f46a6b1e00cf531aabc39045a23d8563a136fc91382` | 213 | `testnet-treasury-unconfigured` |
| `extreme-testnet-marketplace-publish-b-165` | `43cdfcaef0952cc27cee6c489381bcaeba86c641f3d1688beff82e5663374562` | `a4975dddf228f839541666d25fa46e7fbf298fe050d7f403195667d76fd4400c` | 188 | `testnet-treasury-unconfigured` |
| `extreme-testnet-marketplace-purchase-a-166` | `e55231cce1581a2c8ec040765a5a29765df0f80d5dd96573ee1ad9b432a75470` | `b140a4ba0a27f8551799ad85f286b75195010ce3c4060370fa00b28ddd6423f6` | 191 | `testnet-treasury-unconfigured` |
| `extreme-testnet-airdrop-claim-a-trade_1-167` | `4b1af5db7534554bc88ffabc2a87f394e0cae9717bf0a72827cec9bf3936ed43` | `35088f838bf79b69919a1d53685dc3367a5ee8d8f1bdacc8fcdd72d7ccc7c54a` | 205 | `testnet-treasury-unconfigured` |
| `extreme-testnet-airdrop-claim-a-store_1-168` | `6ecc8fb1f501bb0e8ab665f7ca7e4ae477c093c8f22e3d2c48fd00ce91f54e8f` | `f90b130ce5c3caf50d9c3aab9a95f46f6d8235011e1c413bf075b4b3cf4eb9b0` | 205 | `testnet-treasury-unconfigured` |
| `extreme-testnet-chat-dm-a-to-b-169` | `0fcb5eb7faf071722002a5b4e5956f935041ca5df274584e13f66293214117a1` | `fbf043fee824e09af5be2a6bf1683f7e93b3c14946aab088c299e8be0c3f755e` | 283 | `testnet-treasury-unconfigured` |
| `extreme-testnet-airdrop-claim-a-chat_1-170` | `5db02cf6a28a1c7015db583a2c0717d435696eae44f3f5ec11a3982660311361` | `a11444ff058227f3dad837352ab94462c9707a92bd7d548290d1ce797b968c5a` | 204 | `testnet-treasury-unconfigured` |

## Proof export

- proof.zip (account A): `docs/evidence/20260211_195839_extreme-testnet/verify_all/proof_acct-39fc1ab6ffe804ce.zip`
- sha256: `4f3a0917f15df34964c25588ded0f2f94a9d130c96ea9555c8d33281c5cc3923`
