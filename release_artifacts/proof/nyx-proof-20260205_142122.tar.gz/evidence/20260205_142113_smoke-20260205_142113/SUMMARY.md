# NYX verify_all PASS

- seed: 123
- run_id_base: smoke-20260205_142113
- run_session: smoke-20260205_142113-20260205_142113
- timestamp: 20260205_142113
- base_url: http://127.0.0.1:8091
- account_a: acct-d18feaf906fa967d (@a3876acc5)
- account_b: acct-a3606741b8b17ec3 (@b459e785b)

Artifacts:
- verify log: `docs/evidence/20260205_142113_smoke-20260205_142113/verify_all/verify.log`
- manifest: `docs/evidence/20260205_142113_smoke-20260205_142113/verify_all/manifest.json`
- replay outputs: `docs/evidence/20260205_142113_smoke-20260205_142113/verify_all/replay/`

## External integrations (read-only)

- 0x quote: status=200 (`docs/evidence/20260205_142113_smoke-20260205_142113/verify_all/integration_0x_quote.json`)
- Jupiter quote: status=200 (`docs/evidence/20260205_142113_smoke-20260205_142113/verify_all/integration_jupiter_quote.json`)
- Magic Eden collections: status=200 (`docs/evidence/20260205_142113_smoke-20260205_142113/verify_all/integration_magic_eden_collections.json`)
- Magic Eden listings: status=200 (`docs/evidence/20260205_142113_smoke-20260205_142113/verify_all/integration_magic_eden_listings.json`)
- Magic Eden token: skipped

## Runs (state mutations)

| run_id | state_hash | receipt_hash | fee_total | treasury |
|---|---|---|---:|---|
| `smoke-20260205_142113-wallet-faucet-a-nyxt-1` | `a4b8f4151f7351360013c83c7ec26bfdd2bc6f4d2ef8d02bc871bd0755dfec77` | `a4e866491ccd8f647277fe82ddd83ea1062bc6778717bb20023ad2c8aad92e3b` | 157 | `testnet-treasury-unconfigured` |
| `smoke-20260205_142113-wallet-faucet-b-echo-2` | `1c2f46bbad52046019976a09ffa193b26bd319332936c7514e11ceff03fac100` | `3b041be4efc07599a77ad29f3ec4f7387a8b943989d749a388d36629c59392af` | 157 | `testnet-treasury-unconfigured` |
| `smoke-20260205_142113-web2-guard-a-3` | `03468f7ccb890ae074a52e4e59078fb8dcaddd8973b627f8a5b7d0693122ca35` | `3ad0a724232feb928d96b5ac74d45079f9855fe0a9b9bc45a7d22f872d454ab9` | 436 | `testnet-treasury-unconfigured` |
| `smoke-20260205_142113-wallet-transfer-a-to-b-4` | `8fb8eaaf231b3ba85b2d4973c2664d443ac88223d00348ff780916e4d22ee58c` | `df719b585d52d878a92afffd042334ad924b64ac91c3f8162d193394a6da688d` | 200 | `testnet-treasury-unconfigured` |
| `smoke-20260205_142113-exchange-sell-b-5` | `952eebde225cfb858298a0586ad87551125d2d004a2dec4964b02ce704350a7a` | `bf794a41bd47665adf2bac4fb2ff66bfed9ecfe97c5fbf35923080dcdb3f0afd` | 212 | `testnet-treasury-unconfigured` |
| `smoke-20260205_142113-exchange-buy-a-6` | `2c1c43ab9820b1588253bebee2b55abefec4a977c26036c6a95b4a4c577ab27a` | `44a7cccc6c5567c1a8ebe675252b6f383758363e0b4915b3767061419de9de0f` | 211 | `testnet-treasury-unconfigured` |
| `smoke-20260205_142113-marketplace-publish-b-7` | `adda1cc2fabd0eb7ddb1d896acd5ae193b053e10f16aae2395ff7da684abc728` | `6cf82caee4d52edefedf21cf9dd79a6816e15c8837044bbc26eba663d035654e` | 186 | `testnet-treasury-unconfigured` |
| `smoke-20260205_142113-marketplace-purchase-a-8` | `ace25bc051aa22a6bd8257a566317c6a9ddbbcf21d1ce6531d0c5318c470271e` | `3a0aeaf8a187d241b4c1339ee3545fa364e7267b90edd154b14521a22df67800` | 189 | `testnet-treasury-unconfigured` |
| `smoke-20260205_142113-airdrop-claim-a-trade_1-9` | `994c18db5649c630ad3a66aa0d5fb540bfd155a4ca2bb9611c8d89f17e9066e1` | `b66a7d1ab58c22126a2f9e7951ce270bd329be18fe40c2ef7be5aa853fd61160` | 220 | `testnet-treasury-unconfigured` |
| `smoke-20260205_142113-airdrop-claim-a-store_1-10` | `faa6fcf4d2ff20eec85e9e499fec1abbbe37e8d4e36aff087543648c2c531094` | `b69c15c1d7386cc2a5f5bfc118c6ee97bd4e507511f5c2bee2114858a8128c6b` | 228 | `testnet-treasury-unconfigured` |
| `smoke-20260205_142113-chat-dm-a-to-b-11` | `488dc3d9b56e5bbc371a7c992749985c01fc4e1dcd9baedb6d22307ac0a92e02` | `f5fa930d2629ca91dc26f17eb75fa1128a070980e708f21868a777769c6b8c28` | 283 | `testnet-treasury-unconfigured` |
| `smoke-20260205_142113-airdrop-claim-a-chat_1-12` | `d7d9e78fc069640c2e49ff7f3571dad5533d9ce15c6df83af62cfb01eca066ee` | `c1e80bf411625d64a82a0c9b1ebb774ad480ec534286b30dc0066b5a5bf28b88` | 220 | `testnet-treasury-unconfigured` |

## Proof export

- proof.zip (account A): `docs/evidence/20260205_142113_smoke-20260205_142113/verify_all/proof_acct-d18feaf906fa967d.zip`
- sha256: `67341d16b67a05f4806a4db2d985b5ee131eb22b2b44542db9b5ac596382480f`
