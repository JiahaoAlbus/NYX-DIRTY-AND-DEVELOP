# NYX verify_all PASS

- seed: 123
- run_id_base: extreme-testnet
- run_session: extreme-testnet-20260205_142052
- timestamp: 20260205_142052
- base_url: http://127.0.0.1:8091
- account_a: acct-afc78322845c0f58 (@a621ac089)
- account_b: acct-5d4ab840002ab4f1 (@b0f23f7db)

Artifacts:
- verify log: `docs/evidence/20260205_142052_extreme-testnet/verify_all/verify.log`
- manifest: `docs/evidence/20260205_142052_extreme-testnet/verify_all/manifest.json`
- replay outputs: `docs/evidence/20260205_142052_extreme-testnet/verify_all/replay/`

## External integrations (read-only)

- 0x quote: status=200 (`docs/evidence/20260205_142052_extreme-testnet/verify_all/integration_0x_quote.json`)
- Jupiter quote: status=200 (`docs/evidence/20260205_142052_extreme-testnet/verify_all/integration_jupiter_quote.json`)
- Magic Eden collections: status=200 (`docs/evidence/20260205_142052_extreme-testnet/verify_all/integration_magic_eden_collections.json`)
- Magic Eden listings: status=200 (`docs/evidence/20260205_142052_extreme-testnet/verify_all/integration_magic_eden_listings.json`)
- Magic Eden token: skipped

## Runs (state mutations)

| run_id | state_hash | receipt_hash | fee_total | treasury |
|---|---|---|---:|---|
| `extreme-testnet-wallet-faucet-a-nyxt-123` | `db96833fab4312affe2511118674e2606f0292fa6c881bccc2cb37fe93ee3955` | `0bcb6d5ecdc332ca253f991a7dc9646c615e8dae444d37246093bb85df4ee8bc` | 157 | `testnet-treasury-unconfigured` |
| `extreme-testnet-wallet-faucet-b-echo-124` | `ac762ad564096684f6da86d99f2f3a7722f038fb39ea1fbef9ac6f09e5da7128` | `7ddfc629398652ddf932e062d118a553a79496eb1a332123f5ac78ff51278dec` | 157 | `testnet-treasury-unconfigured` |
| `extreme-testnet-web2-guard-a-125` | `47997b115440789ef2b8355b95dc89ebd6ab383fd2aea72146234c72866c3d61` | `a71ac3a0d712bc095b5ed9aec70fb4175d41a7b7dedce0cc86c55569f766477e` | 436 | `testnet-treasury-unconfigured` |
| `extreme-testnet-wallet-transfer-a-to-b-126` | `5b3dec33025b5683438ef33d2fb4a62d30bb07a59e1579a80ac745c066b9a828` | `76480fee04b42d525369cd25cceca815d0d6e957da3df58450dd161f141024ec` | 200 | `testnet-treasury-unconfigured` |
| `extreme-testnet-exchange-sell-b-127` | `fc9aa70daca96fa5ca5581280f9f3b6ee1456f22a318162d401c6b41362b42c3` | `a0ce52582ceb63119e49b832f57d102c2ab89e068ae7d389fce9bc8a5b7b7ee2` | 212 | `testnet-treasury-unconfigured` |
| `extreme-testnet-exchange-buy-a-128` | `a099b0bed5d114041935ad6f217884137928f0c55c56f8bb957eaf25f6fd15a8` | `54603deab8d63e58c86dc8ca8c04d19d64d7af8c6d721c26ae89af1534d6125f` | 211 | `testnet-treasury-unconfigured` |
| `extreme-testnet-marketplace-publish-b-129` | `1256e2eaaaae80bc1b5d54d48696023e03655cd21160a864cd658e20b41af299` | `62e2a714debaf6fd7b0c7c9ef0ec26011ad2cfea34b14fd0c0298167b85c027d` | 186 | `testnet-treasury-unconfigured` |
| `extreme-testnet-marketplace-purchase-a-130` | `fac57a1ed3bb8569ba9de7e3acc2aa6d070369ab10181c128fcc18ad3a1ccbf9` | `456d01921552e09dd7fff170734995946d27d02d5dce0ffe732fa29749fbbf00` | 189 | `testnet-treasury-unconfigured` |
| `extreme-testnet-airdrop-claim-a-trade_1-131` | `f226a27b2d01f50d50fcd4488001e1ed53bfa0eac65de21d815048d5ed9a071e` | `c9e58392fc226ceb09b372dde4ed1f312286a1699f49663a84f12c82a4ba5551` | 216 | `testnet-treasury-unconfigured` |
| `extreme-testnet-airdrop-claim-a-store_1-132` | `fc66d74bd5104cc8ec40ef86edb893ef6766f807d64791dfcb3e01b0dbcee7d0` | `c8e6862bfbad6c83b6bfaab77f014e1e4093e7ead6f56c5b986a021e5f2acea8` | 224 | `testnet-treasury-unconfigured` |
| `extreme-testnet-chat-dm-a-to-b-133` | `6d8ed70268cc26fb3d3d7b6fab539abf5b1ab246b3b2d65fac98f9286a3f240f` | `079a231610eaae035abe8f1852571f7846fd4430bf3906ba221e45a7b5fe24e0` | 283 | `testnet-treasury-unconfigured` |
| `extreme-testnet-airdrop-claim-a-chat_1-134` | `a27d38494829a7834bc950a4e28b7c1c4cae8a125bedfe853335f6b6f9e63fb2` | `27645a1c2fe667030aa9031414b9fd5e7c58670f4801c72d141201e4ec1c4b47` | 215 | `testnet-treasury-unconfigured` |

## Proof export

- proof.zip (account A): `docs/evidence/20260205_142052_extreme-testnet/verify_all/proof_acct-afc78322845c0f58.zip`
- sha256: `65ee8352d09499d8955c6420eea9e382e8bc6a23aa3a1f80516986e7ff9088ae`
