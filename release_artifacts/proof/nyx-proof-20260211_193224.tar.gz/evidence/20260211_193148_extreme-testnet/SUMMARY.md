# NYX verify_all PASS

- seed: 123
- run_id_base: extreme-testnet
- run_session: extreme-testnet-20260211_193148
- timestamp: 20260211_193148
- base_url: http://127.0.0.1:8091
- account_a: acct-b800760af927bbf9 (@a53ab0886)
- account_b: acct-6d4fe49d293d6636 (@b34f7c43c)

Artifacts:
- verify log: `docs/evidence/20260211_193148_extreme-testnet/verify_all/verify.log`
- manifest: `docs/evidence/20260211_193148_extreme-testnet/verify_all/manifest.json`
- replay outputs: `docs/evidence/20260211_193148_extreme-testnet/verify_all/replay/`

## External integrations (read-only)

- 0x quote: status=200 (`docs/evidence/20260211_193148_extreme-testnet/verify_all/integration_0x_quote.json`)
- Jupiter quote: status=200 (`docs/evidence/20260211_193148_extreme-testnet/verify_all/integration_jupiter_quote.json`)
- Magic Eden collections: status=200 (`docs/evidence/20260211_193148_extreme-testnet/verify_all/integration_magic_eden_collections.json`)
- Magic Eden listings: status=200 (`docs/evidence/20260211_193148_extreme-testnet/verify_all/integration_magic_eden_listings.json`)
- Magic Eden token: skipped

## Runs (state mutations)

| run_id | state_hash | receipt_hash | fee_total | treasury |
|---|---|---|---:|---|
| `extreme-testnet-wallet-faucet-a-nyxt-147` | `cd6d444599dbe0e9b23fdaa2e5b06d7a1e1d7852aec0f37ce381a8ee51968499` | `fd248a0c22b23a168cde938cac5659fadb2f9df3567c8cc5de523ab25ecc7022` | 159 | `testnet-treasury-unconfigured` |
| `extreme-testnet-wallet-faucet-b-echo-148` | `5d3c5c14256f01dafa1e11d51d17112f0b06af44f61e528d5cf36f3bcb596168` | `f68c3d2b4f9dba0680d73318c2ce9b9b993310ab6f55d001a6fa261ef3fd3a51` | 159 | `testnet-treasury-unconfigured` |
| `extreme-testnet-web2-guard-a-149` | `aad233afee25d958cb3cd4e62aa68b05647375c50d2d74df9467f670cd132520` | `570a9c4ef0cb99cb766769bf7103395bbbcd8e5e1a8857a84a5a595ed475b3d6` | 437 | `testnet-treasury-unconfigured` |
| `extreme-testnet-wallet-transfer-a-to-b-150` | `f218fd657332b678a48e6daee9587c8c67192bb744c4243fb72b753a3ac1c390` | `9e3320c3bbaf5e5cb811eeda8b25b22525b3a7c0d93d9365eeaa0cb799ef4f6c` | 205 | `testnet-treasury-unconfigured` |
| `extreme-testnet-exchange-sell-b-151` | `afeac63814d30fa16fbc0325e2d7b27f68b51c7ae97716a52987c7349d05ef07` | `c89b0365d909d2ff5e6898518cf2fed815f0d7b0704adad6bdef2dac6fc51ae7` | 214 | `testnet-treasury-unconfigured` |
| `extreme-testnet-exchange-buy-a-152` | `0d0ceca64432053b104a2959e7a350a65edfc1919987e3d6ee3e26a62c8994f1` | `da31a3a830d314a45eb0a8d5ab89649b37c7b7b812e8b82e1120d3064840f88f` | 213 | `testnet-treasury-unconfigured` |
| `extreme-testnet-marketplace-publish-b-153` | `fbb1042db65db8ff934a069d2f24ff82f75b2163d14f1342e81be7576f755af9` | `e599c4bc50b77c1e8de70954779a8a1524a250c47897d307d1c44fcbee6916e7` | 188 | `testnet-treasury-unconfigured` |
| `extreme-testnet-marketplace-purchase-a-154` | `4ba42d3f11ca95bf10ff35d9de2466c5afb5c390070469695798a408e9fbf80d` | `96b06fe29d22d4563e4003008bac461f2fea90ac2f5552e26f89ee49fedd6d71` | 191 | `testnet-treasury-unconfigured` |
| `extreme-testnet-airdrop-claim-a-trade_1-155` | `f7514fe3d2b94c8c0ea6d4a3291f6e6ad4bacbeece5a95dc4a0505f476e505c4` | `eec86a654e233a6a45f594c18b49d32e685d2056126096a769caaf46b031cddf` | 205 | `testnet-treasury-unconfigured` |
| `extreme-testnet-airdrop-claim-a-store_1-156` | `e6dfb1a038874814d81d07305a039875ef2dbe65c2ec58b9fd8dcce4f8e754ab` | `bcaa48bd59b07a5d5de029d88a4fe27f1b080a173f986e2e41364af42fe459db` | 205 | `testnet-treasury-unconfigured` |
| `extreme-testnet-chat-dm-a-to-b-157` | `c3f0a3848ae6f6298d422f735feea1e96e6075ee80ea48de53e87b340b8c0582` | `e2b16d92e0c56f107598f93b3416564acb521c90ed735e0c1ac0c92ae8c8afa5` | 283 | `testnet-treasury-unconfigured` |
| `extreme-testnet-airdrop-claim-a-chat_1-158` | `eabcc4f96c11e6fb44edaec5f842752c2222d47c3da0ad39b35cde0a85d3e24c` | `cafc239316eaddd2d642ead4039749e08d074092953fff46c48d02fc5cd4cf16` | 204 | `testnet-treasury-unconfigured` |

## Proof export

- proof.zip (account A): `docs/evidence/20260211_193148_extreme-testnet/verify_all/proof_acct-b800760af927bbf9.zip`
- sha256: `32be21372ead16c4dd5bcab3b72a0efd1dff023077cece81f2c0705cfba9181b`
