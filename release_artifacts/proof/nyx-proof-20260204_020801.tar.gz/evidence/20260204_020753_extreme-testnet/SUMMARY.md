# NYX verify_all PASS

- seed: 123
- run_id_base: extreme-testnet
- run_session: extreme-testnet-20260204_020753
- timestamp: 20260204_020753
- base_url: http://127.0.0.1:8091
- account_a: acct-25dae2ffb7aa1e8b (@a1dc777d1)
- account_b: acct-50bef52013b8e8e2 (@b78b92e0a)

Artifacts:
- verify log: `docs/evidence/20260204_020753_extreme-testnet/verify_all/verify.log`
- manifest: `docs/evidence/20260204_020753_extreme-testnet/verify_all/manifest.json`
- replay outputs: `docs/evidence/20260204_020753_extreme-testnet/verify_all/replay/`

## Runs (state mutations)

| run_id | state_hash | receipt_hash | fee_total | treasury |
|---|---|---|---:|---|
| `extreme-testnet-wallet-faucet-a-nyxt-71` | `d95d9b0d5d1fc713e962a5a2ccb51fc78c01214c94c590926919651fdaaa20a5` | `d0459b4377cec19858e25a6682c49540f2b0401e3121be5aa9fae25818053e17` | 166 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `extreme-testnet-wallet-faucet-b-echo-72` | `06448ee35282590dbb56f7ad2ede8dc0be5722f7ffb57d13cb9e2702b12352d9` | `8be910d63c35cbe03ee6d12b47c4e4abb33654e82518a75b633029af41a43eef` | 166 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `extreme-testnet-wallet-transfer-a-to-b-73` | `62d4053a33e652c087608ee5aff65d11d08ad13bbf34a48caecb4dec2d145746` | `cf60353efe194d6b7343db5ca5a70ae446959dad142be11a9c11fd7af63e04d4` | 202 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `extreme-testnet-exchange-sell-b-74` | `8cc3091a75f7d9141b96a321d181da8ada1698f64ad6918d416c5a7d1c794dd8` | `434719783bb22abd4bf3212570c6069de03d4e02e656ec740f77d3487bb9e3df` | 212 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `extreme-testnet-exchange-buy-a-75` | `fbcf6ff050cce825e4700afacc95294c69830022dfcbc5e56fdc3107992e102f` | `837f0f250576415274d820225574ecff44aa7af51c8dd8755b4eeaa11725a5e7` | 211 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `extreme-testnet-marketplace-publish-b-76` | `87327823932a86dd03c698dfe27eefd01fc60748d829ef46ab9f3680e17391ba` | `a6dc859a1087da44b6df0fb6a264ef724619be438a4b30da62be05fdc5f6a87f` | 186 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `extreme-testnet-marketplace-purchase-a-77` | `fb72bff5fce5b5dcaa4129904f08e3e8c4fcbdf1e4c12f59071405cf4552c974` | `c3e336444ab589cba419876bb688238a7ddf34583745f55e23205f9831bcd431` | 189 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `extreme-testnet-airdrop-claim-a-store_1-78` | `585ac51dd58ffe41a2fa64f7bd407b177e02e47ce56ab6b69e895d8ad0c406da` | `53daef7e39bdf33cec3ae8573ca546215585b490babd81e63bf84f1ff37a98a8` | 223 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `extreme-testnet-chat-dm-a-to-b-79` | `d568c1335cee3eaf0d2659848f720388f8de2149ae5e4453a2109532e735a358` | `c5bcf275254ece49e05e2d3f4473990d8cd612ffd285d7c04cb9e64318a3a4bd` | 283 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `extreme-testnet-airdrop-claim-a-chat_1-80` | `366edb058c3439128019e082792f31a075a3498e25429e2a7caac850ab26256c` | `8b96b8bd6a17c46a3efcaed361b04a5704989a1e82572112970d23567f1c228d` | 214 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |

## Proof export

- proof.zip (account A): `docs/evidence/20260204_020753_extreme-testnet/verify_all/proof_acct-25dae2ffb7aa1e8b.zip`
- sha256: `5b7c7452671ce821d98d9f1d5ac29edae8159ac46b543423d9d23b16952db174`
