# NYX verify_all PASS

- seed: 123
- run_id_base: smoke-20260204_015954
- run_session: smoke-20260204_015954-20260204_015954
- timestamp: 20260204_015954
- base_url: http://127.0.0.1:8091
- account_a: acct-b1aa4de13afbec8d (@a75891432)
- account_b: acct-dd6687d57716b7ef (@bc67f8a33)

Artifacts:
- verify log: `docs/evidence/20260204_015954_smoke-20260204_015954/verify_all/verify.log`
- manifest: `docs/evidence/20260204_015954_smoke-20260204_015954/verify_all/manifest.json`
- replay outputs: `docs/evidence/20260204_015954_smoke-20260204_015954/verify_all/replay/`

## Runs (state mutations)

| run_id | state_hash | receipt_hash | fee_total | treasury |
|---|---|---|---:|---|
| `smoke-20260204_015954-wallet-faucet-a-nyxt-1` | `90727575d4180d9b5b3b39617cd09997b831e1216564c167920e3c4541e11d7d` | `d54901d1b4439dc9191e87a3131a44d0779c0a2eed25bc01ab3b28e6b932f4d8` | 166 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `smoke-20260204_015954-wallet-faucet-b-echo-2` | `31c06f9be34bef603e62913ac9d198ca387b7ef2e9a4ef31a575f83b0629bf47` | `bbac1680ed0cbe51073e54fb6ea7ecf66e2d472fa457a95fd19b52eb75a316e7` | 166 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `smoke-20260204_015954-wallet-transfer-a-to-b-3` | `0be027779dc43581d089df477447e65e55b0f9e7bcac25e141fc94333d976cc4` | `22c5776600d4f5c1c4f52b2bff62eb834714b8dca8c9615a281c2314cd62d806` | 202 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `smoke-20260204_015954-exchange-sell-b-4` | `0096e4ce4c5a90dda1861c72cc3e5a59e44e6b7857c00159f33985c7d5aef67b` | `9eb14842d18ae26f064bcda4c0305a399263867f11822b444eee5221ef8d95c9` | 212 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `smoke-20260204_015954-exchange-buy-a-5` | `c120192b77b73571126c73feb4a2246680dd383ff28c7da65e5d176c32c82c2f` | `239f774bb0611746e6e60694d5ddf410483919566409a1c6e6b9b808c44f4d35` | 211 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `smoke-20260204_015954-marketplace-publish-b-6` | `f116f5fd528beb73fc5a3f5ada985ba105e2a6af4a983601dd4ce73b0741b670` | `2ccb1d84787c8f9d558f7802f1a25b73d165f636bc9b2880c2ada684f3454f20` | 186 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `smoke-20260204_015954-marketplace-purchase-a-7` | `26e26ec36c54bcaa4fcb8f473a89958c9b3561761a8a94d3a8984aa7b8f2b288` | `c8268c75ecaff1de6e37e574d1a0329a24000bc98176541222f6f17f68524768` | 189 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `smoke-20260204_015954-airdrop-claim-a-store_1-8` | `25b935db1dfed665f6b2c8bdc3042db23b09b5aa95cf8a20c5f5737a5cf807c3` | `8f302e06d37aeae4d62961f0fb2edd5303666e52c37a603f0efd39e23d6b8283` | 228 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `smoke-20260204_015954-chat-dm-a-to-b-9` | `3ee6454bd445d8a7b238563194df04a0b81b4421573d8af0cbc6c4a5803c559d` | `bfe23eb2c7bfa7a15c80bcfec667b3f0c8d00046eb1f902adb4022d5c7db3af3` | 283 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `smoke-20260204_015954-airdrop-claim-a-chat_1-10` | `031d400f334d9d2113eb5306c13cc4c0c9bf189bee20242e150b84e7abc7725e` | `6efc7fb7be47354f16c81a94c6249cdbcd9dc389eae0915e1e190982aac38f2e` | 219 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |

## Proof export

- proof.zip (account A): `docs/evidence/20260204_015954_smoke-20260204_015954/verify_all/proof_acct-b1aa4de13afbec8d.zip`
- sha256: `60d9b0867f3de06c6c7dc830e2c14e741758d5cbaf83bd01c8f7152b4e98314c`
