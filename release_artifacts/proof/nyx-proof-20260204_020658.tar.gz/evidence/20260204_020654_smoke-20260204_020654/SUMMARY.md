# NYX verify_all PASS

- seed: 123
- run_id_base: smoke-20260204_020654
- run_session: smoke-20260204_020654-20260204_020654
- timestamp: 20260204_020654
- base_url: http://127.0.0.1:8091
- account_a: acct-1f934a9e5cd29b49 (@a1232aa84)
- account_b: acct-7ee8e16df973761e (@b5eb37973)

Artifacts:
- verify log: `docs/evidence/20260204_020654_smoke-20260204_020654/verify_all/verify.log`
- manifest: `docs/evidence/20260204_020654_smoke-20260204_020654/verify_all/manifest.json`
- replay outputs: `docs/evidence/20260204_020654_smoke-20260204_020654/verify_all/replay/`

## Runs (state mutations)

| run_id | state_hash | receipt_hash | fee_total | treasury |
|---|---|---|---:|---|
| `smoke-20260204_020654-wallet-faucet-a-nyxt-1` | `729cbd9a1a893700bac2a9ffef300bbbe856284908868fc0103e466522ebc22d` | `266438535a42cac870f2fcdb94dd15769213c61c6c482385a3214262d0f8045d` | 166 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `smoke-20260204_020654-wallet-faucet-b-echo-2` | `2a1cb548ab8e836367e05ed3b485f2c572167897db396fae801e6ecd972a2533` | `67abde3e1ce0fba56ec641a26c377a90d1521ba696149d65a59a12bc2ce00bab` | 166 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `smoke-20260204_020654-wallet-transfer-a-to-b-3` | `76402b2d70eb468f6161c99fb571c9b02b99abe753ec8c374e67d03440ebc789` | `d29e1b9c08d31a65c71c0b6294ae8fd4953eb7acb305f0c9c0238b8a526b33da` | 202 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `smoke-20260204_020654-exchange-sell-b-4` | `ef6a587f9a579ce4aceac3fcfb242f2fa603d1df82931ed59d1205f8451be5f2` | `89ede57f6313598063ffffb75ee428eb214635d35ab9b3f055eaa2969bc4e78f` | 212 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `smoke-20260204_020654-exchange-buy-a-5` | `b78cb19709bc3033e11dc8f772c110cbdc6ff3556a66e53eaf5b58fd86d83fc5` | `18b6c987035da80fbdbdfd794b6250c49b8bb9511d01cfe5b81cebd04c1f17d9` | 211 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `smoke-20260204_020654-marketplace-publish-b-6` | `1f0365931b76037cad6763b36ee20b2b330370c1cc1cb5484647560711e18e18` | `b72d3b587d2a8e318bbde1f3d1c88251ce34c628cac46b96996cd26d3a23ce90` | 186 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `smoke-20260204_020654-marketplace-purchase-a-7` | `3162c2dcffb6216100b4ab3f497632e012f1b76b5314a28c315efffa72292984` | `d5072093f756b183ff7d1a3c4362791763fc94ecf6b0f60a6842f078dcf1067c` | 189 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `smoke-20260204_020654-airdrop-claim-a-store_1-8` | `7df00832425160a84b7506f939babecb6779bd8edf22cbbb0dd93e6ae1149ec3` | `5d788acd108f2ead08a5f4c51ffd0007860a85a56b0f295b1cbaf58706186864` | 228 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `smoke-20260204_020654-chat-dm-a-to-b-9` | `0d5defd25bbbc2d9b4621881f33e329ff25f7c2fd0edcdb8a31962cd0fa41c95` | `81631ba1a7bc19f6682c5d963e8c61fb065a2b9221b3261533802da576fc99bd` | 283 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `smoke-20260204_020654-airdrop-claim-a-chat_1-10` | `0dd072e654c8ce95e4d9fc1168191e955c31f6751ac53be86beb1e181dc517cd` | `ba4e1008d35743e37f07af7c68cd14d9b8fa2f28fab76f2e097b9d1721f0c84d` | 219 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |

## Proof export

- proof.zip (account A): `docs/evidence/20260204_020654_smoke-20260204_020654/verify_all/proof_acct-1f934a9e5cd29b49.zip`
- sha256: `d5239fefd253fe396a993ada9551a7e46086dcac89e46e691cb35daf3d5b6b52`
