# NYX-DIRTY Extreme Gap Report (Full-Stack Audit)

Audit date: **2026-02-03**

Scope: **Current repo workspace** (`/Users/huangjiahao/Desktop/NYX/nyx`) focusing on **real usability** (no fake UI), **capabilities-driven rendering**, and **deterministic state mutations with evidence**.

Legend:
- **🔴 Broken/Fake**: UI exists but cannot complete a real backend action + state refresh + evidence.
- **🟡 Partial**: Some path works but missing determinism, receipts surfaced, pagination, or consistent error/loading.
- **🟢 OK**: Works end-to-end and surfaces receipt/state_hash + replay.

## Global Gaps (Cross-Cutting)

| Area | Status | Evidence (code-based) | Fix Plan |
|---|---:|---|---|
| Determinism First (seed/run_id) | 🔴 | `nyx-world/api.ts` uses `Math.random()` + `Date.now()` for `seed`/`run_id` across **faucet/transfer/orders/chat/store/airdrop**. | Refactor to **single deterministic run context** (seed + baseRunId + monotonic counter) and require every mutation to take `{seed, run_id}` from UI. Files: `nyx-world/api.ts`, `nyx-world/App.tsx`, screens that call mutation APIs. |
| Single Source of Truth: `/capabilities` | 🔴 | `nyx-world/App.tsx` fetches `/capabilities`, but only `Home` partially gates `dapp.browser`; `BottomNav` renders all modules regardless. | Centralize capability parsing + `can(module, feature)`; hide/disable unsupported modules/buttons with explicit UX. Files: `nyx-world/App.tsx`, `nyx-world/components/BottomNav.tsx`, `nyx-world/screens/Home.tsx`, module screens. |
| Unified API client (timeout/error map/retry idempotent) | 🔴 | `nyx-world/api.ts` has `requestJson` without timeout, no 401/403/429 mapping, no retry rules, throws generic `Error(message)`. | Introduce `ApiClient` with timeout, typed `ApiError{status,code,message}`, retry only GET/HEAD, consistent JSON parsing. Files: `nyx-world/api.ts` (replace), shared UI error components. |
| NO FAKE UI gate (runtime) | 🔴 | Multiple UI buttons/screens do nothing or show placeholder/static data: `Wallet` Send button, `Home` “More”, `Fiat` “Buy NYXT”, `Web2Access` “Establish Secure Connection”, `Exchange` chart demo candles. | Disable/hide with tooltip + copy, or wire to real endpoints + evidence. Files: `nyx-world/screens/*.tsx`, `apps/nyx-ios/Views/ModuleViews.swift`. |
| Backend: missing functions referenced by server | 🔴 | `apps/nyx-backend-gateway/src/nyx_backend_gateway/server.py` calls non-existent `gateway.execute_wallet_faucet_v1`, `gateway.marketplace_list_active_listings`, `gateway.marketplace_search_listings`. | Implement missing gateway functions or change server to call existing storage helpers. Files: `apps/nyx-backend-gateway/src/nyx_backend_gateway/gateway.py`, `apps/nyx-backend-gateway/src/nyx_backend_gateway/server.py`. |
| Activity feed completeness | 🔴 | `apps/nyx-backend-gateway/src/nyx_backend_gateway/portal.py:list_account_activity` joins receipts via tables but references `chat_messages.run_id` (column does not exist per `migrations.py`). Missing marketplace purchases linkage. | Fix activity linkage to include **wallet transfers, exchange orders, marketplace purchases/listings, chat message_events** by joining correct tables/columns. Files: `apps/nyx-backend-gateway/src/nyx_backend_gateway/portal.py`, `apps/nyx-backend-gateway/src/nyx_backend_gateway/migrations.py` (if new columns). |

---

## Module Audit Tables

### 0) Portal / Auth / Capabilities

| UI Entry | Backend endpoint | MutatesState | Evidence | Status | Current Unusable Reason | Fix Plan (file + function) |
|---|---|---:|---:|---:|---|---|
| Web onboarding “Create Account + Sign In” (`nyx-world/screens/Onboarding.tsx`) | `POST /portal/v1/accounts` → `POST /portal/v1/auth/challenge` → `POST /portal/v1/auth/verify` | Yes | No (portal ops don’t create evidence bundles) | 🟡 | Works, but **seed used for portal key is not tied to global deterministic seed**; injected-session flow is incomplete. | `nyx-world/App.tsx:loadSession` must call `GET /portal/v1/me` when `__NYX_SESSION_TOKEN__` exists to recover `account_id/handle`. |
| Capabilities bootstrap | `GET /capabilities` | No | No | 🔴 | Capabilities are fetched but **not enforced** globally (nav + buttons still show disabled modules). | `nyx-world/App.tsx` add parsed capability state + pass to all screens; `BottomNav` gate tabs. |

### A) Wallet (+ Faucet) — “MetaMask-level”

| UI Entry | Backend endpoint | MutatesState | Evidence | Status | Current Unusable Reason | Fix Plan (file + function) |
|---|---|---:|---:|---:|---|---|
| Wallet balance header (`nyx-world/screens/Wallet.tsx`) | `GET /wallet/balance?address=...` | No | No | 🟡 | Only supports a single `balance` (NYXT) and **hardcoded asset list** (USDX shows 0). | Add `GET /wallet/balances?address=...` (multi-asset) + update `Wallet.tsx` to render real assets. Backend: `apps/nyx-backend-gateway/src/nyx_backend_gateway/server.py` + `storage.py` query. |
| Wallet “Send” button | (should call) `POST /wallet/v1/transfer` (auth) | Yes | Yes | 🔴 | **Button is wired to `onClick={() => {}}`** (no action). | Implement native send flow UI with validation + call deterministic transfer. Files: `nyx-world/screens/Wallet.tsx` (add Send modal/screen), `nyx-world/api.ts:transferWallet` (remove randomness). |
| Wallet “Receive” | No endpoint (display address + copy) | No | No | 🟡 | Address copy works; lacks QR (optional). | Add QR (optional), keep deterministic text-only ok. |
| Faucet screen “Request Tokens” (`nyx-world/screens/Faucet.tsx`) | `POST /wallet/v1/faucet` (auth) | Yes | Yes | 🔴 | Backend route uses missing `gateway.execute_wallet_faucet_v1` so request fails; client also uses random seed/run_id and doesn’t refresh wallet state. | Backend: implement `gateway.execute_wallet_faucet_v1` (cooldown/quota/errors) or route to existing `execute_wallet_faucet`. Web: use `{seed, run_id}` from Settings and refresh balances + show fee + receipt hashes. |
| Wallet Tx History | `GET /portal/v1/activity` | No | N/A | 🔴 | Wallet activity tab shows “No transactions yet” static; backend activity linkage incomplete. | Web: render activity list + details w/ `state_hash` + `receipt_hashes` and link to Evidence. Backend: fix `portal.list_account_activity`. |
| Fees + treasury route per mutation | `/run` + fee summary fields | Yes | Yes | 🔴 | Wallet/Exchange/Store UIs show **static fee text** or none; wallet faucet doesn’t surface fee. | Surface server response `fee_total`, `fee_breakdown`, `treasury_address` in mutation success UI and evidence inspector. |

### B) Exchange / Trade — “Binance Lite”

| UI Entry | Backend endpoint | MutatesState | Evidence | Status | Current Unusable Reason | Fix Plan (file + function) |
|---|---|---:|---:|---:|---|---|
| Order book view (`nyx-world/screens/Exchange.tsx`) | `GET /exchange/orderbook` | No | No | 🟡 | Loads but no pagination/filters; relies on whatever backend returns. | Add pagination params (`limit/offset`) support or incremental refresh; update UI to show loading/empty/retry. |
| Place order (`Exchange` form) | `POST /run` module=`exchange` action=`place_order` (auth) | Yes | Yes | 🔴 | Client uses random seed/run_id; no validation; fee shown static “0.10%”; success doesn’t show receipt/state_hash. | Use deterministic run context; validate amount/price; show server fee + receipt/state_hash; link to Evidence replay. Files: `nyx-world/screens/Exchange.tsx`, `nyx-world/api.ts:placeOrder`. |
| Chart | (none) | No | No | 🔴 | Uses hardcoded candle data (2024-01-01..). | Remove until real market data endpoint exists, or compute from `/exchange/trades` and render. |
| Cancel order | `POST /run` action=`cancel_order` (auth) | Yes | Yes | 🟡 | API exists but UI doesn’t expose cancel flow; ownership checks are TODO in backend (`gateway.py`). | Add Open Orders list w/ cancel buttons; backend: enforce ownership for cancel via DB. |

### D) Store / Marketplace — “Taobao-lite”

| UI Entry | Backend endpoint | MutatesState | Evidence | Status | Current Unusable Reason | Fix Plan (file + function) |
|---|---|---:|---:|---:|---|---|
| Listings grid (`nyx-world/screens/Store.tsx`) | `GET /marketplace/listings` | No | No | 🔴 | Backend handler calls missing `gateway.marketplace_list_active_listings`; UI expects fields like `item.rate` but backend listing uses `price`. | Backend: implement `marketplace_list_active_listings` + `marketplace_search_listings`. Web: render `price`, show seller, support pagination/empty/retry. |
| Purchase flow (cart button) | `POST /run` module=`marketplace` action=`purchase_listing` (auth) | Yes | Yes | 🔴 | Client uses random seed/run_id; purchase history UI assumes `created_at` which is not in `purchases` schema. | Add `created_at` to purchases (migration) or remove timestamp from UI; surface receipt/state_hash/fee; refresh balances immediately. |
| “My Orders” | `GET /marketplace/purchases?limit&offset` | No | N/A | 🟡 | Endpoint exists but data model incomplete; UI needs pagination + proper fields. | Update purchases schema/model + UI list; add filters by buyer_id (auth) for “My Orders”. |

### C) Chat — “IG-smooth + real E2EE”

| UI Entry | Backend endpoint | MutatesState | Evidence | Status | Current Unusable Reason | Fix Plan (file + function) |
|---|---|---:|---:|---:|---|---|
| Room list | `GET /chat/v1/rooms` (auth) | No | No | 🟡 | Lists rooms, but message send path is mismatched (see below). UI also shows fake “stories” user_1..3. | Remove fake story UI; implement search via `/portal/v1/rooms/search`; ensure room selection drives message fetch/send on same backend storage. |
| Send message | Currently calls `POST /run` module=`chat` action=`message_event` | Yes | Yes | 🔴 | UI fetches messages from `/chat/v1/rooms/{id}/messages` but sends to `/run` (stored in `message_events`). Also `sendChatMessage()` **double-encrypts**. | Align: use `/run` + fetch from `GET /chat/messages?channel=...` (message_events). Fix encryption to single pass and implement real per-room key management rules. Files: `nyx-world/api.ts`, `nyx-world/screens/Chat.tsx`. |
| E2EE | Client-side AES-GCM with key derived from constant string `NYX_SECRET_${roomId}` | Yes (message send) | Yes | 🔴 | Key derivation is effectively global/guessable; not a real key exchange; violates “session key per conversation” requirement. | Implement minimal key exchange + per-room session key; document rules in `docs/PROTOCOL_INVARIANTS.md` or `docs/RULES_ADDENDUM.md`. |

### E) Faucet / Airdrop

| UI Entry | Backend endpoint | MutatesState | Evidence | Status | Current Unusable Reason | Fix Plan (file + function) |
|---|---|---:|---:|---:|---|---|
| Faucet | `POST /wallet/v1/faucet` | Yes | Yes | 🔴 | Backend route missing handler impl; web uses random seed/run_id; no cooldown/quota surfaced. | Backend: implement v1 faucet with explicit error codes for cooldown/quota/ip/account; Web: deterministic run ids, retry, refresh balance, show fee and treasury route. |
| Airdrop tasks list | `POST /wallet/airdrop/claim` | Yes | Yes | 🔴 | UI tasks are fake (Follow on X/Discord). Backend allows claim by arbitrary `task_id` and reward (no real task verification). | Implement 1–2 real tasks (e.g. “completed trade”, “sent chat msg”, “store purchase”) by verifying receipts; expose `GET /wallet/airdrop/tasks` for UI; disable fake tasks. |

### F) Evidence Center

| UI Entry | Backend endpoint | MutatesState | Evidence | Status | Current Unusable Reason | Fix Plan (file + function) |
|---|---|---:|---:|---:|---|---|
| Evidence inspector (`nyx-world/screens/Activity.tsx`) | `GET /portal/v1/activity` + `GET /evidence?run_id=...` + `GET /export.zip` | No | N/A | 🟡 | Works for runs that appear in activity feed; activity feed is incomplete; evidence UI doesn’t surface fee/treasury summary explicitly. | Fix backend activity feed linkage; enhance UI to show fee/treasury + inputs/outputs summary + “Verify Replay” result differences. |

### G) iOS (Native wallet + Web portal modules)

| UI Entry | Backend endpoint | MutatesState | Evidence | Status | Current Unusable Reason | Fix Plan (file + function) |
|---|---|---:|---:|---:|---|---|
| iOS Home “Claim Airdrop” | (none) | No | No | 🔴 | `Button(action: {})` no-op. | Hide/disable until airdrop tasks are real, or wire to WebPortal Airdrop screen with capability gating. File: `apps/nyx-ios/Views/ModuleViews.swift`. |
| iOS Wallet | `GET /wallet/balance` (no auth) | No | No | 🔴 | Uses hardcoded address; send/buy/swap are no-op; doesn’t share portal session. | Make wallet use `settings.session.account_id` and authenticated v1 endpoints for faucet/transfer; surface receipt/state_hash. Files: `apps/nyx-ios/Views/ModuleViews.swift`, `apps/nyx-ios/Network/GatewayClient.swift`. |
| iOS WebPortal session sharing | WebView injects `__NYX_SESSION_TOKEN__` | N/A | N/A | 🟡 | Token injection exists, but web app sets `account_id="injected"` instead of calling `/portal/v1/me`. | Fix web `loadSession()` to call `fetchPortalMe` when injected. File: `nyx-world/App.tsx`. |
| iOS Tab bar mapping | N/A | N/A | N/A | 🔴 | `AppShellView` Settings tab sets `selectedTab = 5` but Settings view is `.tag(6)` (opens Evidence by mistake). | Fix tag/action mapping. File: `apps/nyx-ios/Views/AppShellView.swift`. |

---

## Immediate Execution Order (per spec)

1. **Fix backend missing functions + v1 faucet path** (unblocks Wallet/Faucet/Store).
2. **Make Web deterministic + capabilities-driven + unified API errors**.
3. **Wallet + Faucet end-to-end** (balance/assets/send/history/evidence/fees).
4. **Exchange end-to-end** (orderbook/pagination/place/cancel/fills/fees).
5. **Store end-to-end** (listings/purchase/orders/fees).
6. **Chat end-to-end** (E2EE, consistent storage, activity receipts).
7. **Evidence Center extreme** (verify replay, export proof package).
8. **iOS native wallet + web portal alignment**.

