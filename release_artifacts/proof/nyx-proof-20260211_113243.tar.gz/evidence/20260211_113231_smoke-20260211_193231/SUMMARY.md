# NYX verify_all PASS

- seed: 123
- run_id_base: smoke-20260211_193231
- run_session: smoke-20260211_193231-20260211_113231
- timestamp: 20260211_113231
- base_url: http://127.0.0.1:8091
- account_a: acct-bd3379aa24d84053 (@a81942fc9)
- account_b: acct-2e6720e695b2e4b0 (@bf411cec1)

Artifacts:
- verify log: `docs/evidence/20260211_113231_smoke-20260211_193231/verify_all/verify.log`
- manifest: `docs/evidence/20260211_113231_smoke-20260211_193231/verify_all/manifest.json`
- replay outputs: `docs/evidence/20260211_113231_smoke-20260211_193231/verify_all/replay/`

## External integrations (read-only)

- 0x quote: status=200 (`docs/evidence/20260211_113231_smoke-20260211_193231/verify_all/integration_0x_quote.json`)
- Jupiter quote: status=200 (`docs/evidence/20260211_113231_smoke-20260211_193231/verify_all/integration_jupiter_quote.json`)
- Magic Eden collections: status=200 (`docs/evidence/20260211_113231_smoke-20260211_193231/verify_all/integration_magic_eden_collections.json`)
- Magic Eden listings: status=200 (`docs/evidence/20260211_113231_smoke-20260211_193231/verify_all/integration_magic_eden_listings.json`)
- Magic Eden token: skipped

## Runs (state mutations)

| run_id | state_hash | receipt_hash | fee_total | treasury |
|---|---|---|---:|---|
| `smoke-20260211_193231-wallet-faucet-a-nyxt-1` | `cb4ed17f6c2b4a607f5b6e7ced0d057f70de8ebbb6ce085f599f46401bd39da6` | `d92e36cbf25ca0cd39d8dea3e279eb1eb9110a321e1a9bff2f81acd2942bee9c` | 159 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193231-wallet-faucet-b-echo-2` | `d6fd84d2144c9181697e62fecd2b6d47443be0da088b05afc45d6dcf9b331c46` | `892889b2d9d4543201c30a4dfacc57f083211d9b8f49b72f6be880cfb46d0115` | 159 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193231-web2-guard-a-3` | `67167409eae9b6418404096ab54ab6d2d40191832f6d170db907dcf03327efc8` | `ca71daab50806984191fac3f22f5d609718907617afcb0ad8f5d5420fdb6ecec` | 437 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193231-wallet-transfer-a-to-b-4` | `d6c7508b63a6ee62ea94c33218448cc8180be6c5ec9beb32258610e2eea60cb0` | `d4ea0cadc1140944b6e383a7c0fa5253c5eeb85767cd27dea6962080a5c195c9` | 205 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193231-exchange-sell-b-5` | `6490c292b1ccbaea6abfe8cba695b1be6d5e77551dbede459115002e2fbe4993` | `549120b9eed94413ddbbf45e5f5faa30adbf9f0b6e2135cab9d02f8763aa97e8` | 214 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193231-exchange-buy-a-6` | `f1b5ad3339dcdb501660a0310030683c8d0729ee5ecc8bd3d769abd3f347be96` | `be7f7d52f6d729e2e0feea7c0c2343cdece8ffc94066803c464a4315cee09c85` | 213 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193231-marketplace-publish-b-7` | `74201d17d3c38a6cdabd7fd07cbaacf3c019a79dabf66264b33c582b912a1da3` | `5fa7fe9c83494c80bd7e8578cf30efb1efd509e6d64cd2e32ae93f8a59164a5f` | 188 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193231-marketplace-purchase-a-8` | `17c1ef1173707e97dfe04160ef5ebeed632e3075fdb4083b35c7883b4dc22252` | `854130bd86fd1f0d9fbfefa6854ebcb67a0e29db6493bf3d8412bf1d062989d3` | 191 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193231-airdrop-claim-a-trade_1-9` | `47baabd4b0732529492bfc2097daa932fadb91a6db60bf37d8715fa5b1a01d7e` | `77190730ebe89ab89675b9d6963023c365612676ff7cc3eafc2ad35016e2da51` | 205 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193231-airdrop-claim-a-store_1-10` | `9981b1d847f7f83aebeae52956f39824099e39c6b3aa277aa98787c97ee6701a` | `2cf3ff191b03129ed8330d1272302c63d9a75fd5fdb5c3877b1a793a48b78378` | 205 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193231-chat-dm-a-to-b-11` | `b64646d6b4674bd695a04d409a586c3caf159b82666d07ce987177c0cc5c62a1` | `2846c09b766d6b11c360da990672d7a0b192e6bdbd32ddfb2f3b60b4c5779c51` | 283 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193231-airdrop-claim-a-chat_1-12` | `cfadacd0d443e552f6e2e63361ebc6e5d7acd2bfba2a91afa342b7c5b30c7f64` | `41b7dd91acf31ddc3ac545af6156edae6124b864fd69688e5490dafe6c102dcf` | 204 | `testnet-treasury-unconfigured` |

## Proof export

- proof.zip (account A): `docs/evidence/20260211_113231_smoke-20260211_193231/verify_all/proof_acct-bd3379aa24d84053.zip`
- sha256: `9dc01143ca85c8aad336b78781095c2305c64f68f231f79ac2bfac411a63ebae`
