# NYX verify_all PASS

- seed: 123
- run_id_base: smoke-20260211_195903
- run_session: smoke-20260211_195903-20260211_115903
- timestamp: 20260211_115903
- base_url: http://127.0.0.1:8091
- account_a: acct-d7836f105c5c942c (@aac9c069f)
- account_b: acct-ee791fd49d4bf882 (@b2900a700)

Artifacts:
- verify log: `docs/evidence/20260211_115903_smoke-20260211_195903/verify_all/verify.log`
- manifest: `docs/evidence/20260211_115903_smoke-20260211_195903/verify_all/manifest.json`
- replay outputs: `docs/evidence/20260211_115903_smoke-20260211_195903/verify_all/replay/`

## External integrations (read-only)

- 0x quote: status=200 (`docs/evidence/20260211_115903_smoke-20260211_195903/verify_all/integration_0x_quote.json`)
- Jupiter quote: status=unknown (`docs/evidence/20260211_115903_smoke-20260211_195903/verify_all/integration_jupiter_quote.json`)
- Magic Eden collections: status=unknown (`docs/evidence/20260211_115903_smoke-20260211_195903/verify_all/integration_magic_eden_collections.json`)
- Magic Eden listings: skipped
- Magic Eden token: skipped

## Runs (state mutations)

| run_id | state_hash | receipt_hash | fee_total | treasury |
|---|---|---|---:|---|
| `smoke-20260211_195903-wallet-faucet-a-nyxt-1` | `6eb14ba773835265f0a21e82e66a28a951ec8f788f8a601e6838360a072579c4` | `d2056e16a28b4c67cb9414fd99ae7ec02fb3bb8f9958eac88ccde69a1db65b5c` | 159 | `testnet-treasury-unconfigured` |
| `smoke-20260211_195903-wallet-faucet-b-echo-2` | `1e8d63e53a2b0f7874385ff2c0422440902341545678413c4d1a839460b42e03` | `d1ca9da98e36f88bd34d8dd1e4ced5f15ac49d947e012efcf46a36746588ae95` | 159 | `testnet-treasury-unconfigured` |
| `smoke-20260211_195903-web2-guard-a-3` | `aad233afee25d958cb3cd4e62aa68b05647375c50d2d74df9467f670cd132520` | `570a9c4ef0cb99cb766769bf7103395bbbcd8e5e1a8857a84a5a595ed475b3d6` | 437 | `testnet-treasury-unconfigured` |
| `smoke-20260211_195903-wallet-transfer-a-to-b-4` | `3305316d59d80b2ccbfd3bcfb0dbbb15f15467ed2c0e81586b67b7ea17e3565e` | `7ab4fef0ac098a207aaf22eca4809e217de4ddd5af6e8a9c6d1024226e290ff2` | 205 | `testnet-treasury-unconfigured` |
| `smoke-20260211_195903-exchange-sell-b-5` | `2edf71a8c06327dd964fe20a49e48a15a0584daf60d758d4c5dd1de1f59cf1dd` | `13fd1c2761b874ff10a82cf3efa386f1c889bb58bb314378e493e4154dd7ceda` | 214 | `testnet-treasury-unconfigured` |
| `smoke-20260211_195903-exchange-buy-a-6` | `0cc5d87292ce7dab5589cbd5ffc9b3718b97d211b214bae12039ce4f577f58c0` | `e1676805d836d7bc06f7f947abb6df1e2b047873544c1ef79cace5ae3867c2c0` | 213 | `testnet-treasury-unconfigured` |
| `smoke-20260211_195903-marketplace-publish-b-7` | `304aab8e283db8b55c13a587dea3c308a6a9f46057f86ae1f9669887ef1bab8e` | `330bc79f586901b7355f408fc3931e2cbb3e4f6c337adf6bdc49836d56d07f26` | 188 | `testnet-treasury-unconfigured` |
| `smoke-20260211_195903-marketplace-purchase-a-8` | `8e8aa04a56994215fd273be27e128ac52690dacacc6a368134c58bf28e33a8f2` | `ffc09548576f9ef1478aa4f3539b64076ab3d550520d4a59b5b28eb36aefe1ae` | 191 | `testnet-treasury-unconfigured` |
| `smoke-20260211_195903-airdrop-claim-a-trade_1-9` | `f4aa8e1c5f0491736512e08bb4cc37e41a61c3e76a33ef64b348b9e70fed21d5` | `d6692c10815839693f8cd62fb3ddef344c54cad1049e8913fc98e79668190f91` | 205 | `testnet-treasury-unconfigured` |
| `smoke-20260211_195903-airdrop-claim-a-store_1-10` | `65ce7ff1b77f2f246ed9f7b70b92015efc0c2c8a915a37246f6117f6ad329d8d` | `d20eb92f6f0c02d57a15ed22eb46ede6027c21511a482eba81ca8de50a7aeb6a` | 205 | `testnet-treasury-unconfigured` |
| `smoke-20260211_195903-chat-dm-a-to-b-11` | `b1405f6fd7126683650daffa98ca381ec488cd4f922ab5527b98817fa987fa3f` | `f4e45445918f6c4351774db7f615a75af6dc0fe43b59bbffe48a2d65e5a32761` | 283 | `testnet-treasury-unconfigured` |
| `smoke-20260211_195903-airdrop-claim-a-chat_1-12` | `dcfb7b8b45e87dc9fb76105876985b75fe343da1758f38ae0490272ab72b022c` | `944b51fd879f0ea51b0ebae4b133bb36bc1927092c748ca5d1952e033565a064` | 204 | `testnet-treasury-unconfigured` |

## Proof export

- proof.zip (account A): `docs/evidence/20260211_115903_smoke-20260211_195903/verify_all/proof_acct-d7836f105c5c942c.zip`
- sha256: `f07f99cba5158a9ec0f6958d783537c3a0d643b00d57fb07d31591bce73a23e0`
