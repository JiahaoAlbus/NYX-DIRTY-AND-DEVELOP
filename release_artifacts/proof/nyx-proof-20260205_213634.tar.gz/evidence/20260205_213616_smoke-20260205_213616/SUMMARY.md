# NYX verify_all PASS

- seed: 123
- run_id_base: smoke-20260205_213616
- run_session: smoke-20260205_213616-20260205_213616
- timestamp: 20260205_213616
- base_url: http://127.0.0.1:8091
- account_a: acct-e67fa84882663efa (@a44173ad9)
- account_b: acct-b830ff35b3c43063 (@bdb39d6e3)

Artifacts:
- verify log: `docs/evidence/20260205_213616_smoke-20260205_213616/verify_all/verify.log`
- manifest: `docs/evidence/20260205_213616_smoke-20260205_213616/verify_all/manifest.json`
- replay outputs: `docs/evidence/20260205_213616_smoke-20260205_213616/verify_all/replay/`

## External integrations (read-only)

- 0x quote: status=200 (`docs/evidence/20260205_213616_smoke-20260205_213616/verify_all/integration_0x_quote.json`)
- Jupiter quote: status=200 (`docs/evidence/20260205_213616_smoke-20260205_213616/verify_all/integration_jupiter_quote.json`)
- Magic Eden collections: status=200 (`docs/evidence/20260205_213616_smoke-20260205_213616/verify_all/integration_magic_eden_collections.json`)
- Magic Eden listings: status=200 (`docs/evidence/20260205_213616_smoke-20260205_213616/verify_all/integration_magic_eden_listings.json`)
- Magic Eden token: skipped

## Runs (state mutations)

| run_id | state_hash | receipt_hash | fee_total | treasury |
|---|---|---|---:|---|
| `smoke-20260205_213616-wallet-faucet-a-nyxt-1` | `4f6494b211f0cf049cb922baad487ba728cd2dec39a720e8a53945876531df4f` | `473aec02950395aa08a0a4ecfa1bdd3c2baae0abe959232900c8f2d308ef791e` | 157 | `testnet-treasury-unconfigured` |
| `smoke-20260205_213616-wallet-faucet-b-echo-2` | `89a55e4da89d34b47a5b1535fc9f0c3bc3691bb316701a24cb75b2c40ece5d9f` | `1b92b0feec1d895879ceb35770a67ad542477e28cb811225f36cbacc9df2531f` | 157 | `testnet-treasury-unconfigured` |
| `smoke-20260205_213616-web2-guard-a-3` | `bdb2ca66c234ea697a2a86d7ef66ef8f234ed59e5071395442c2c722aae40c55` | `cf667af94a8005ed37f26e2f0d33c1efdfcf9801f71c25b48e94894ec0589d4d` | 436 | `testnet-treasury-unconfigured` |
| `smoke-20260205_213616-wallet-transfer-a-to-b-4` | `9b81f85c5f98fd0f1bd2df65226f39472a84f70808a5b33d20192bc31a588ec6` | `ad8ab78f4cca293d766d7e64f9feb737e5b7883e5766c31e4a90dc2b650e6aad` | 200 | `testnet-treasury-unconfigured` |
| `smoke-20260205_213616-exchange-sell-b-5` | `72c2b9094956c37248b0c218f12d91cbfcd39265fe84ea8d90c7701187f1bb36` | `3d1737e2f2797d3b5f66fc28b658d0851cf27374d4a1ef0921db3ef7087a28c0` | 212 | `testnet-treasury-unconfigured` |
| `smoke-20260205_213616-exchange-buy-a-6` | `2bf53f218b74bcf60f9d2fd2addcb621f05e8142eed7bdd7dfb6ed402c295297` | `d879c48f927ea5ed267e91026ae6309ac3eccfcbbe992b795883e48668bf44f6` | 211 | `testnet-treasury-unconfigured` |
| `smoke-20260205_213616-marketplace-publish-b-7` | `39a645d059d5689a467d94b13ec2c8de52600059fa986fca68f0e361894b3f86` | `cdfe195d43fca72e47ff488dc1ad5249eeb1e7bc481ac3ce2069301f3ce5ade3` | 186 | `testnet-treasury-unconfigured` |
| `smoke-20260205_213616-marketplace-purchase-a-8` | `95be0b090943b2e1e4a893c9abef496bde3b3f9372413196dfd20ce89288d66e` | `d105dbb957cbb58a29072fefed8b12bc5ffe896ea17500cda92d28b55cd755a1` | 189 | `testnet-treasury-unconfigured` |
| `smoke-20260205_213616-airdrop-claim-a-trade_1-9` | `1927ddc5e05ae165dec7f161c0eafd0d2e63ee2a3635df77f1cfb58336bf8046` | `0b57dbb8bf8dcbbd8c633ecd0b55d3909b4c81ffbbb4f2b041ca917786be572b` | 220 | `testnet-treasury-unconfigured` |
| `smoke-20260205_213616-airdrop-claim-a-store_1-10` | `85fdcf2be1e7fc617ee51bc1f1c2bcb459701414ad0c825f349ed8a123bea320` | `e041a937ef5d49f49f97271d52d6dffb2efea42ffc1ea09ca5ed130029c3e747` | 228 | `testnet-treasury-unconfigured` |
| `smoke-20260205_213616-chat-dm-a-to-b-11` | `4fd4d3edda7c986a8394258974a3525893a3909c2ef3ed8960aa02a58e03664c` | `de44cdd9f214aefb091722550df064dbf46a1e5e025783096f786c0c1b5bdceb` | 283 | `testnet-treasury-unconfigured` |
| `smoke-20260205_213616-airdrop-claim-a-chat_1-12` | `508a1a53cfbb5c12e6f2c288df6b0705f916b13e254869661af12f5bff766e98` | `439f7108c8769d16a81cc186dc9fa28af4d5752463c523beecba2fbbf3338a6b` | 220 | `testnet-treasury-unconfigured` |

## Proof export

- proof.zip (account A): `docs/evidence/20260205_213616_smoke-20260205_213616/verify_all/proof_acct-e67fa84882663efa.zip`
- sha256: `2823cee6a8c05673210c11554576c741daf47061a2d096fb8cc695934001938e`
