# NYX verify_all PASS

- seed: 123
- run_id_base: conformance
- run_session: conformance-20260208_192513
- timestamp: 20260208_192513
- base_url: http://127.0.0.1:8091
- account_a: acct-ea0aea9f04206304 (@aa98e023a)
- account_b: acct-bb42af0a9bb6ed8b (@b5c3e71e6)

Artifacts:
- verify log: `docs/evidence/20260208_192513_conformance/verify_all/verify.log`
- manifest: `docs/evidence/20260208_192513_conformance/verify_all/manifest.json`
- replay outputs: `docs/evidence/20260208_192513_conformance/verify_all/replay/`

## External integrations (read-only)

- 0x quote: status=200 (`docs/evidence/20260208_192513_conformance/verify_all/integration_0x_quote.json`)
- Jupiter quote: status=200 (`docs/evidence/20260208_192513_conformance/verify_all/integration_jupiter_quote.json`)
- Magic Eden collections: status=200 (`docs/evidence/20260208_192513_conformance/verify_all/integration_magic_eden_collections.json`)
- Magic Eden listings: status=200 (`docs/evidence/20260208_192513_conformance/verify_all/integration_magic_eden_listings.json`)
- Magic Eden token: skipped

## Runs (state mutations)

| run_id | state_hash | receipt_hash | fee_total | treasury |
|---|---|---|---:|---|
| `conformance-wallet-faucet-a-nyxt-61` | `3cd9852fbf831f8301b31ace9d106426a70bfc5cbbe07691d1077d3c24dbb756` | `a65bdfbf4b7fd46d4313c2a7987a8f4e330199b1b175c6f93fbd59c9fb97f631` | 157 | `testnet-treasury-unconfigured` |
| `conformance-wallet-faucet-b-echo-62` | `f22655800ae30974117ca11d5a4a3479c9b10e970f060b8a0d2ea5610cc08c03` | `5a11eaeda13053f5c402cde982f3c1f4a3af3c9e235e446a61a5956ab3bca4c9` | 157 | `testnet-treasury-unconfigured` |
| `conformance-web2-guard-a-63` | `7ca8e8873ae3668ddebf03fa966f4b9998b1f12e04763cf73f56b09945f2de90` | `937e5f5ea2a940c3246e44032ae9f083af4dd2c749d4dd7598a000155be69f67` | 437 | `testnet-treasury-unconfigured` |
| `conformance-wallet-transfer-a-to-b-64` | `d593e0b0ebcbba4ac702b45ded1c7f1c2bbc2f8b132d876adf63ad08e7db5e08` | `d88eb0f2d978c92eb325069d508dc3c98f692217405dda058fd9c6094d36e844` | 200 | `testnet-treasury-unconfigured` |
| `conformance-exchange-sell-b-65` | `c657e490536faf348ab4c3a3d894c79aab7e5c7c47c52487ab655bf5ec11bd3d` | `c29c1d6a72b323a51cfee5cdc88186459888701da33fa5f37debe1998bc7c946` | 212 | `testnet-treasury-unconfigured` |
| `conformance-exchange-buy-a-66` | `36373e00162b7160617fcb72d49ea83869cdd20368f975aa63211812eb4e7a77` | `c50da5c275ac08beaebf0f48fc506286927f3e7e871b6134d9c14f14e79ae76a` | 211 | `testnet-treasury-unconfigured` |
| `conformance-marketplace-publish-b-67` | `0061bec792f1c74f51cad9023fb119d2150227b254db7af16ff37ea37b787208` | `bf8db5437be241015c12142bbfcb71ce63a962a534dfb5f65044e771060078ab` | 186 | `testnet-treasury-unconfigured` |
| `conformance-marketplace-purchase-a-68` | `8aa6cae12b43bb8bba19283fc39ebfc4d141517957cd1beaecec3959625a8b10` | `e3858475eda9ce38ea83d4dfdf083b071dcf3b72948c6cfb01120746bf0c8776` | 189 | `testnet-treasury-unconfigured` |
| `conformance-airdrop-claim-a-trade_1-69` | `2cd48841e2f54dcb33b7f111a790415e722b60a9dfb6cf67ed3b95ba6218dc19` | `e508ee03e47084c190a60756ed649a994f2a8174f0f4ee856f733d1d5eb6b4e3` | 162 | `testnet-treasury-unconfigured` |
| `conformance-airdrop-claim-a-store_1-70` | `4ee689297ea3a9a290484fdb7c2b1711767e3e009954d0a8379f4d160018e7d0` | `50eacf66c9847964933d246474a445c34dca77fd95df60ab385004a24232a6f3` | 162 | `testnet-treasury-unconfigured` |
| `conformance-chat-dm-a-to-b-71` | `f97aa28abad469317e2eee80bfc871c059ad6aff0931f9f9d33c230b8334b1ed` | `52093696e527e6e6f0c8948627712b5a8a71c929170579a4b79f99356b9c667b` | 283 | `testnet-treasury-unconfigured` |
| `conformance-airdrop-claim-a-chat_1-72` | `3d5f6ef1b53d14787e3f1e9dcdb70e72bec27334182a74976c984f4a2df039a0` | `2f5736bde448d7856e83954da7ab43fb7c70f147c7e0cca97caf6ccfac539aae` | 161 | `testnet-treasury-unconfigured` |

## Proof export

- proof.zip (account A): `docs/evidence/20260208_192513_conformance/verify_all/proof_acct-ea0aea9f04206304.zip`
- sha256: `5c6dcc5771703166ff04cc57f0f27afc35ae4a1f71d67e3abda6889af146670e`
