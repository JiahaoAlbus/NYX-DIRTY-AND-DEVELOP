# NYX verify_all PASS

- seed: 123
- run_id_base: conformance
- run_session: conformance-20260208_185050
- timestamp: 20260208_185050
- base_url: http://127.0.0.1:8091
- account_a: acct-a3eb80d473b59e92 (@a0cb4edc6)
- account_b: acct-69a8637b93d800a7 (@bd20ea83a)

Artifacts:
- verify log: `docs/evidence/20260208_185050_conformance/verify_all/verify.log`
- manifest: `docs/evidence/20260208_185050_conformance/verify_all/manifest.json`
- replay outputs: `docs/evidence/20260208_185050_conformance/verify_all/replay/`

## External integrations (read-only)

- 0x quote: status=200 (`docs/evidence/20260208_185050_conformance/verify_all/integration_0x_quote.json`)
- Jupiter quote: status=200 (`docs/evidence/20260208_185050_conformance/verify_all/integration_jupiter_quote.json`)
- Magic Eden collections: status=200 (`docs/evidence/20260208_185050_conformance/verify_all/integration_magic_eden_collections.json`)
- Magic Eden listings: status=200 (`docs/evidence/20260208_185050_conformance/verify_all/integration_magic_eden_listings.json`)
- Magic Eden token: skipped

## Runs (state mutations)

| run_id | state_hash | receipt_hash | fee_total | treasury |
|---|---|---|---:|---|
| `conformance-wallet-faucet-a-nyxt-13` | `c864086d32566be45ef0e342fa3c24901a676c77e54a5e0fc3ef91690eb9dabb` | `9e3ada77c64398ba609c403e0f88d30db1d2381af2b6c444e7edd1e1f4129814` | 157 | `testnet-treasury-unconfigured` |
| `conformance-wallet-faucet-b-echo-14` | `9a1148a6aa4c97d270f15670d8c97a563bebd11f63c0ed0d57b14ec0f0c5c964` | `657f9002a9defd30c18d0c7b0b1bf4ad429e20d397203457ab483aac03790457` | 157 | `testnet-treasury-unconfigured` |
| `conformance-web2-guard-a-15` | `aad233afee25d958cb3cd4e62aa68b05647375c50d2d74df9467f670cd132520` | `570a9c4ef0cb99cb766769bf7103395bbbcd8e5e1a8857a84a5a595ed475b3d6` | 437 | `testnet-treasury-unconfigured` |
| `conformance-wallet-transfer-a-to-b-16` | `b64c9c16f71be50ec62cf0a2b99abe41733c11ee9a05c7370964140fc4a8c062` | `c59a71f9812449a6aeb863bd414050e60713273c06a99aa842eac000242d6386` | 200 | `testnet-treasury-unconfigured` |
| `conformance-exchange-sell-b-17` | `f6c7f023502a663095cdf38bf32edc9390efda992756304ee3cab2c6f071af38` | `79e5d0787a4cb771d2a6d8daec18c30fa8ecd8594dc2a76fafe65c4a08c50f1f` | 212 | `testnet-treasury-unconfigured` |
| `conformance-exchange-buy-a-18` | `02422cc0a24d4593970b25e8ede1bd616d4453cf97f41e66ca1c5b4df029cbb4` | `ea9c934d77b09a8e12a2966d874233ee60129e8ba473f7eb3ac9e606997d21db` | 211 | `testnet-treasury-unconfigured` |
| `conformance-marketplace-publish-b-19` | `065a84394d9656c6be5d942bf82cc88980f725ea9ca3f564411e2c213a64cbdd` | `7ef96dc803c7b603b336e4073b00e27c59d23a5205f74fa75843bfedce9c92a3` | 186 | `testnet-treasury-unconfigured` |
| `conformance-marketplace-purchase-a-20` | `4014f69229736b88e404458df9ee8af37616f4022f7ae659e50df6d30eafb459` | `5033df5ec503770f4dcbad819cccf877bb6957284fdbe16241ca7c9c35a8f5aa` | 189 | `testnet-treasury-unconfigured` |
| `conformance-airdrop-claim-a-trade_1-21` | `f0062c2dd8222abf889e67a846714571b4d6bd296e49e17e8386f1c5d74f7fd2` | `5600fc1beb5ac3d0657c7a2766001b091c8d5eb6bfa442797a27a5c2fce4426b` | 162 | `testnet-treasury-unconfigured` |
| `conformance-airdrop-claim-a-store_1-22` | `f25c32a014b06d383c8c48f5a42abe6772ee6ee32b5657fdc622fda7963c87aa` | `ae2f2117688dcf15e2acb0e7e551a159247a57201b07c5e79d4aab3e4719f28a` | 162 | `testnet-treasury-unconfigured` |
| `conformance-chat-dm-a-to-b-23` | `cea4edf0b4f2430469a5284212f05f0c3552f8525f1f291180e5da6d7ac2288f` | `7369566e20d224340387c94d3549609efedf8bdb0adae44e31b4fcaea5f7dc15` | 283 | `testnet-treasury-unconfigured` |
| `conformance-airdrop-claim-a-chat_1-24` | `307ec06362e6cb5be4b673fdffcdc35393ea4d28692a107c5a8efabe588541f9` | `5201bcf5354c22a42e8a5f65ab4007b26f7bbc6d2be494c0d531a3f583926fa7` | 161 | `testnet-treasury-unconfigured` |

## Proof export

- proof.zip (account A): `docs/evidence/20260208_185050_conformance/verify_all/proof_acct-a3eb80d473b59e92.zip`
- sha256: `03001da57c62cb122646ada1d9550a9eee1e6917166fe109d888d075faf1f6bf`
