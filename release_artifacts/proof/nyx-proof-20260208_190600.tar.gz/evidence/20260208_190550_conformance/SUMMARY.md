# NYX verify_all PASS

- seed: 123
- run_id_base: conformance
- run_session: conformance-20260208_190550
- timestamp: 20260208_190550
- base_url: http://127.0.0.1:8091
- account_a: acct-5059fd8b8ac61462 (@a0cd7e275)
- account_b: acct-1199753463726714 (@baf1e905d)

Artifacts:
- verify log: `docs/evidence/20260208_190550_conformance/verify_all/verify.log`
- manifest: `docs/evidence/20260208_190550_conformance/verify_all/manifest.json`
- replay outputs: `docs/evidence/20260208_190550_conformance/verify_all/replay/`

## External integrations (read-only)

- 0x quote: status=200 (`docs/evidence/20260208_190550_conformance/verify_all/integration_0x_quote.json`)
- Jupiter quote: status=200 (`docs/evidence/20260208_190550_conformance/verify_all/integration_jupiter_quote.json`)
- Magic Eden collections: status=200 (`docs/evidence/20260208_190550_conformance/verify_all/integration_magic_eden_collections.json`)
- Magic Eden listings: status=200 (`docs/evidence/20260208_190550_conformance/verify_all/integration_magic_eden_listings.json`)
- Magic Eden token: skipped

## Runs (state mutations)

| run_id | state_hash | receipt_hash | fee_total | treasury |
|---|---|---|---:|---|
| `conformance-wallet-faucet-a-nyxt-25` | `68a9d9166b47dd302b563daf6359d9f72d8da0929e7a6e9d6299ba0d5610c169` | `1cb079f018ae34968bbe41a0fa0e5ce8439de570ed8505d436ce8889e3cca7db` | 157 | `testnet-treasury-unconfigured` |
| `conformance-wallet-faucet-b-echo-26` | `404f5d8dfd21665d463066e8e9e5d593d702dc87e75cb9f9215a7c628c909bcc` | `578b5ddf3e7b4b985be23dc0c6a67d39485e271bbd39911add04b373c93e3881` | 157 | `testnet-treasury-unconfigured` |
| `conformance-web2-guard-a-27` | `4f96d4e7b30ac78fe06f897d31b885de01369c8a03bccab4a10dfbed52a33351` | `8eecf45ea744b07f7b2e96ebc16960b2aae17c4619e7b1fd911e23c98901c27a` | 437 | `testnet-treasury-unconfigured` |
| `conformance-wallet-transfer-a-to-b-28` | `4a6defbcbf9429310504a08cfc1a0a05203a9239261e8fc21452d4befdaf2dd8` | `a2a97a69288680ab0711b5c156da807a05e7401a9fdb242a4d2324a3e6ab8112` | 200 | `testnet-treasury-unconfigured` |
| `conformance-exchange-sell-b-29` | `778e63784b862f5661a23440b54bd943fe77559bc03a31f5d2a2bf05f25d64c4` | `0a7590b0b4719a5fd44eb4c1d215e99111832daf1b6eaf97d29de4d4f354f2ec` | 212 | `testnet-treasury-unconfigured` |
| `conformance-exchange-buy-a-30` | `09693c0de92e7f1f778cc384dc6db50bc88ce76be1688c213509476676d43253` | `ef17aa1c7bb26b7389ebe88d730ace1eee766a2b5d5b17919c7286d0fbc1396a` | 211 | `testnet-treasury-unconfigured` |
| `conformance-marketplace-publish-b-31` | `d1e0ead4f842c5b7cf7206714a34aae22c40216ae77e2c743c72fe87c8bb22ab` | `708a25901840e587fd7e4ea5aa07b400712bf45a5e64df19d03e6f50906c9fc9` | 186 | `testnet-treasury-unconfigured` |
| `conformance-marketplace-purchase-a-32` | `b7998fcf8be5f18eab865d163146d2f704500ceb5b8c5902dc0996ff7bbd1eee` | `82ca4104272a26afaba932a5127aaef7bbd444bcda61e0386379cc691896e0ca` | 189 | `testnet-treasury-unconfigured` |
| `conformance-airdrop-claim-a-trade_1-33` | `fbdbcea431eaa8ef042066584f08e802573ee63824c020e929cc02fe5985bebc` | `7c08a15f9e07717e218894f0b9b168db95e9c7e0940dc948a0cc8bd7578e8efb` | 162 | `testnet-treasury-unconfigured` |
| `conformance-airdrop-claim-a-store_1-34` | `d52f76699b2d7a2e0171a06eea2e9683a9b9ebf0c72fb8e7c2cd51d875dec9de` | `62035fc4909983e639eab8e74c25547595d6c32684f1a9db4a42a683386cdbf4` | 162 | `testnet-treasury-unconfigured` |
| `conformance-chat-dm-a-to-b-35` | `483bd94fa3bea07b86d06f5127879da9a715a13c083203a23f91187db365bf92` | `3ed1c9fbbf5b74a9f52d12245b20538a0f44296b89aa28aa450f057cdd2fcb98` | 283 | `testnet-treasury-unconfigured` |
| `conformance-airdrop-claim-a-chat_1-36` | `34d62b41caa1f7b3041c50071b88d950aae765f0db6bcc672c8e263051dd5df3` | `5a56fb503b0eb978e304903425df199cd968e67cff416d87584482a9a54a3fcb` | 161 | `testnet-treasury-unconfigured` |

## Proof export

- proof.zip (account A): `docs/evidence/20260208_190550_conformance/verify_all/proof_acct-5059fd8b8ac61462.zip`
- sha256: `4b415ee6bf0046184c6ab6821794e1c58c5362e05aeaa7818133e753bfbe0e4e`
