# NYX verify_all PASS

- seed: 123
- run_id_base: smoke-20260205_001615
- run_session: smoke-20260205_001615-20260205_001615
- timestamp: 20260205_001615
- base_url: http://127.0.0.1:8091
- account_a: acct-1c1fd448c8a98ccf (@ae018b37b)
- account_b: acct-f3cf83e16bc88b96 (@b623fc208)

Artifacts:
- verify log: `docs/evidence/20260205_001615_smoke-20260205_001615/verify_all/verify.log`
- manifest: `docs/evidence/20260205_001615_smoke-20260205_001615/verify_all/manifest.json`
- replay outputs: `docs/evidence/20260205_001615_smoke-20260205_001615/verify_all/replay/`

## External integrations (read-only)

- 0x quote: skipped
- Jupiter quote: skipped

## Runs (state mutations)

| run_id | state_hash | receipt_hash | fee_total | treasury |
|---|---|---|---:|---|
| `smoke-20260205_001615-wallet-faucet-a-nyxt-1` | `06e9e5ccaebb577098276488589d035b9a06616c41599de69c14d587dfb85081` | `1f2b203b5b00f7454d28c03719520cad01b839353e3008a32f87ed350f34e8b3` | 206 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `smoke-20260205_001615-wallet-faucet-b-echo-2` | `42923b08d3b11e83e6ddfec629fc816dbdf6bfe54fee7a1b35480ec919a23209` | `bf7bc64ef656739a379956e792d89a0e3965868630f6ec808a1a3a17cef9753a` | 166 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `smoke-20260205_001615-web2-guard-a-3` | `2c0437a667fec40d8a57c6011abce7a8baea840cd67d937233e5d8d4c55e1210` | `df9d87d4dc2af88a5f8204cdf491add24f55d2fd478bb0df17a5355c8e5a47ab` | 436 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `smoke-20260205_001615-wallet-transfer-a-to-b-4` | `934941cdb155d52d48a20180071878dfa5fb22566cd113f3c23bbc0e8c65bc88` | `2f1f211829fd972f7191ae6a62e2ddb3737952109941d5835d329c882aa7bb12` | 202 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `smoke-20260205_001615-exchange-sell-b-5` | `067759812811151cf9cd92ab955c0e2252c59fe063c7ce2ad6654b9f3fdd0f23` | `b8a7334288cc2744ae9ebc6c738c5bd26ece8c62fd3be12f43d349dfb6e11f22` | 212 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `smoke-20260205_001615-exchange-buy-a-6` | `fac0913df851872c7f10f1e99da83e6e12b3160fd8ce1eb6742d77c3879ae0b7` | `3b4ae290266c2e12ab2209726f44a2efd3f08e11b051453184aaa8b41d4078e2` | 211 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `smoke-20260205_001615-marketplace-publish-b-7` | `fee40f1509eff448f870d83acfc52fb13aab7f396cf133fb5f47679d9095cbc1` | `a47009100399d900d51f94c8d05ac51d021f1c449c2df9e6f2c43c19ed7941d4` | 186 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `smoke-20260205_001615-marketplace-purchase-a-8` | `a8ebd5de82149c6b79563e21d084e8f2846a072128689eafc5e8c0c0978f9a78` | `07ab7e0d8e2697e558154a1c32af138e9357c13145041ca5527a0f66f3573e34` | 189 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `smoke-20260205_001615-airdrop-claim-a-trade_1-9` | `aa8545942b4c936fcaca2c3347d389e0d23b21e2270541aca6ebce6e2372b3ce` | `13a2d85c2c5417ef912d2428565f71d83c68cd683f17f95ebbaa00330ea0dc74` | 220 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `smoke-20260205_001615-airdrop-claim-a-store_1-10` | `697c4d28d2dfcf6d5a974f0550c8d54af5b5093612a7e9db31aefacfa63d7ce8` | `32e481def7909d3bc20ca29fb5fd793344ae861e5c1bcac5f48fac0ad1931ae9` | 228 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `smoke-20260205_001615-chat-dm-a-to-b-11` | `83603302459fbd7dbdb8b1efeafa1145f0637f6af0552a846360dfc120cd355f` | `060eabddb6ab7ae0bde36f1462134ec94c57d52179f6e84a0a27c173c091dd89` | 283 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `smoke-20260205_001615-airdrop-claim-a-chat_1-12` | `366efb4f4cccc8d650f546adc5672a565ac559281032fc225111575ab294fd57` | `5e0462621520d92bd2e70434d3b2acaa9147d2293aa4d7c88c55ce53031ae8c1` | 220 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |

## Proof export

- proof.zip (account A): `docs/evidence/20260205_001615_smoke-20260205_001615/verify_all/proof_acct-1c1fd448c8a98ccf.zip`
- sha256: `0ff91293f4aa674108d08ba466b245df8acfd4640513405c14f92f6f97acdd83`
