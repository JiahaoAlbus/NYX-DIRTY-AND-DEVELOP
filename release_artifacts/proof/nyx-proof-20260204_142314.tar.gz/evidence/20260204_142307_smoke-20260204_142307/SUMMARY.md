# NYX verify_all PASS

- seed: 123
- run_id_base: smoke-20260204_142307
- run_session: smoke-20260204_142307-20260204_142307
- timestamp: 20260204_142307
- base_url: http://127.0.0.1:8091
- account_a: acct-44a32ecd8cc22634 (@a8a338530)
- account_b: acct-3b8fefdaf10022f1 (@bbec21789)

Artifacts:
- verify log: `docs/evidence/20260204_142307_smoke-20260204_142307/verify_all/verify.log`
- manifest: `docs/evidence/20260204_142307_smoke-20260204_142307/verify_all/manifest.json`
- replay outputs: `docs/evidence/20260204_142307_smoke-20260204_142307/verify_all/replay/`

## External integrations (read-only)

- 0x quote: skipped
- Jupiter quote: skipped

## Runs (state mutations)

| run_id | state_hash | receipt_hash | fee_total | treasury |
|---|---|---|---:|---|
| `smoke-20260204_142307-wallet-faucet-a-nyxt-1` | `f580c07c8c3f67f3be49ac6657537f615778dd4a8ad1027ee920bdafa0372e2c` | `1acf9e9ff4ca2eea54b47d4cb94234205f8663a686eaac5d809b19b037463857` | 166 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `smoke-20260204_142307-wallet-faucet-b-echo-2` | `5670c6b26c7a669125c7471ed6dd2a55fca3f1d81ef9866e65a08c365fa0e932` | `baeaf23bbe9626d5e87fb3c430de66c79075a85d64734a0bd52d1debdb103dbe` | 166 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `smoke-20260204_142307-wallet-transfer-a-to-b-3` | `2817d45c1572beca330c0f7e9d89ae94cbf3b3db388b29408e89e9b5d36d9aef` | `9108d6198905cf3e6e13963b60d2456f8d3e11c9f48e12702fb7a04e1d11cb88` | 202 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `smoke-20260204_142307-exchange-sell-b-4` | `0fb5169bd90f6ee8f6570935b4ce1a1968d24f391da196f6c25d71e9ce13016e` | `ce2c175527aa80a4eeb61b01e1cde6009e30b373919804882dfeb0370c752ccc` | 212 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `smoke-20260204_142307-exchange-buy-a-5` | `2f0ec67ed096fed2bfcd11d9fef6de47a5a167d64c3f6f84c3abae8147dc868b` | `c110d6eca877d19ca7b5ac5cb67c53ad8466e99f344954dcbe38e282580b9c54` | 211 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `smoke-20260204_142307-marketplace-publish-b-6` | `051f0e88edcdf99613d1242f61c44a5fc80f867e356856bbabb49225ecf16038` | `4a2f6dcb3b701008641b665f982f17d681e8605a44c959fa716800ea648e6636` | 186 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `smoke-20260204_142307-marketplace-purchase-a-7` | `427ef16afe9e4148b5cc2a7d9d0bc88e6cbd8db037a2ef0e3e810660fe995a13` | `86df3bc0da9c34fc7531fcb80fb8b3b34d7cb7795b01a53b2b7132debf31ede3` | 189 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `smoke-20260204_142307-airdrop-claim-a-store_1-8` | `93b4d59b90e303fbf9fedf5fcb08b149dcafa0601a3806a7cbc6ba85ea17e5fd` | `5ce4541c9656f506e6877e2f26fba34a2835e5759d11d4091e46ee9f949a4666` | 228 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `smoke-20260204_142307-chat-dm-a-to-b-9` | `e4715ae89e2daebc0774f7fc0724bb65045822e9b23092a81c875ceba18e46ac` | `25de2723ffd6a14afe00a321b5e8671c172d095642e2fbc250d2cf6c9112809c` | 283 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `smoke-20260204_142307-airdrop-claim-a-chat_1-10` | `6b7bfe98e771efaf87a2d7602bad23e52300f9a36be57526fd830b6febc2177a` | `e49c56a498508838c75391135b493048834477b174c5732db8747f9d248d7887` | 219 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |

## Proof export

- proof.zip (account A): `docs/evidence/20260204_142307_smoke-20260204_142307/verify_all/proof_acct-44a32ecd8cc22634.zip`
- sha256: `efbea41224ee1f02d173392ebc2e3d978316896502b0b2d3563e9b10907e7f4f`
