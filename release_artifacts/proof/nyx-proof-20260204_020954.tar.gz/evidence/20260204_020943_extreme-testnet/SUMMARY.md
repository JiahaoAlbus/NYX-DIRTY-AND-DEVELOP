# NYX verify_all PASS

- seed: 123
- run_id_base: extreme-testnet
- run_session: extreme-testnet-20260204_020943
- timestamp: 20260204_020943
- base_url: http://127.0.0.1:8091
- account_a: acct-dc9316918b11f243 (@a7dc0153a)
- account_b: acct-5dc009d41f865c8c (@baed868d3)

Artifacts:
- verify log: `docs/evidence/20260204_020943_extreme-testnet/verify_all/verify.log`
- manifest: `docs/evidence/20260204_020943_extreme-testnet/verify_all/manifest.json`
- replay outputs: `docs/evidence/20260204_020943_extreme-testnet/verify_all/replay/`

## Runs (state mutations)

| run_id | state_hash | receipt_hash | fee_total | treasury |
|---|---|---|---:|---|
| `extreme-testnet-wallet-faucet-a-nyxt-81` | `479dd5ff5260d55bd2e6672cb3ae4980a142ed4fc279e3f6e8af55bca3dda88c` | `8ec0f0ea9eab291c7b5df87793c41e7bdc19047188cdacd454159a944b95b739` | 166 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `extreme-testnet-wallet-faucet-b-echo-82` | `fd7a330365a906286a729bea3201ade0737031455afdc11f747343150bd03a5e` | `020dec65b808669b68b1839271c516f060e83f3aa6d3f27d19dcab4ea9d6dc7f` | 166 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `extreme-testnet-wallet-transfer-a-to-b-83` | `887359754c4c61efa1f7149f8d7d6b2970d2f5fb6726b57f655b5ba59868c84d` | `b7adcdc67a3e4d41cac0f03442dd60531887e182ff98a3caed531ac42fc06e4e` | 202 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `extreme-testnet-exchange-sell-b-84` | `7e46b58bb3b74e131775991a6170f197be2f71fe926bc7a6fbdd84442f7a9339` | `b40e992b8fcb763f3d510e8d84290bdf147c582eb0611d697dee87981915b565` | 212 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `extreme-testnet-exchange-buy-a-85` | `c0a7ed5d192a3fd608cb75fb50fa26a626c05408d967f14521168c6e221521b8` | `1fcc89a35e95a2ae44d177ab31a5317940ea2e025fb67333cf340c0f877f28bb` | 211 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `extreme-testnet-marketplace-publish-b-86` | `889b14f8f26bebb9ccc517b65fa42c00a4ce3d4acc0baac4a6bba96db102ba5a` | `fc874aa148554edaec35c8d6ba5fd879ca2f23ad93b45e99f37349086859e11f` | 186 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `extreme-testnet-marketplace-purchase-a-87` | `03ed4be3a582c3701650d31231ca35bd308e16c1dd6f4387ebc1a1f6f84d120c` | `a81c97f4dad14de6a56531b97705518f1923bbec60b62e2fb2905ff4302688fd` | 189 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `extreme-testnet-airdrop-claim-a-store_1-88` | `15a59bc7eea3b0750c610c8d744cb9bd73fe38a20225a1825e35f68671797b67` | `f6b5b83247f50925f919fe80de9378323465faf8c44a1d2dd5683d029646ac7e` | 223 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `extreme-testnet-chat-dm-a-to-b-89` | `b0c78e79e831dad3743b0344289d3040d96b5d20c9582cad1e44d350ced45f04` | `51d32584d151d9f1888a3eeafa7fb1f4e8df0356e62f978e00243a147fe29ad1` | 283 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |
| `extreme-testnet-airdrop-claim-a-chat_1-90` | `e6e4a66085ddd8aae8412fbcaf00a933995e74893285b68bd1cc5ccbdb9a71c4` | `b763af34424f67ad6ce09de218963e9a8c5aee35882fa3e9d9b7e3900c076422` | 214 | `NYX_TESTNET_TREASURY_PLACEHOLDER` |

## Proof export

- proof.zip (account A): `docs/evidence/20260204_020943_extreme-testnet/verify_all/proof_acct-dc9316918b11f243.zip`
- sha256: `30801ec2a69ff1b2f2dfff9524d56a031c6675bd76b3f1f0cb9a556eae8c57d0`
