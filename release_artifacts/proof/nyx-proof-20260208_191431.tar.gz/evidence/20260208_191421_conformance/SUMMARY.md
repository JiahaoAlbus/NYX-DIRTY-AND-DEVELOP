# NYX verify_all PASS

- seed: 123
- run_id_base: conformance
- run_session: conformance-20260208_191421
- timestamp: 20260208_191421
- base_url: http://127.0.0.1:8091
- account_a: acct-48300cd76b430446 (@ac06a196d)
- account_b: acct-e3bb4b225cbf4864 (@b2261f4ee)

Artifacts:
- verify log: `docs/evidence/20260208_191421_conformance/verify_all/verify.log`
- manifest: `docs/evidence/20260208_191421_conformance/verify_all/manifest.json`
- replay outputs: `docs/evidence/20260208_191421_conformance/verify_all/replay/`

## External integrations (read-only)

- 0x quote: status=200 (`docs/evidence/20260208_191421_conformance/verify_all/integration_0x_quote.json`)
- Jupiter quote: status=200 (`docs/evidence/20260208_191421_conformance/verify_all/integration_jupiter_quote.json`)
- Magic Eden collections: status=200 (`docs/evidence/20260208_191421_conformance/verify_all/integration_magic_eden_collections.json`)
- Magic Eden listings: status=200 (`docs/evidence/20260208_191421_conformance/verify_all/integration_magic_eden_listings.json`)
- Magic Eden token: skipped

## Runs (state mutations)

| run_id | state_hash | receipt_hash | fee_total | treasury |
|---|---|---|---:|---|
| `conformance-wallet-faucet-a-nyxt-37` | `d128f115e14607249852fe7d52c9c5a53b29ad293757c7020a4644408050ebf9` | `d6cae007916c9be163d120174163dbffe11e090af34c14d49fd11f46c2f35f7f` | 157 | `testnet-treasury-unconfigured` |
| `conformance-wallet-faucet-b-echo-38` | `6edefdaae86d80d3eebec77980ea8e02845d9c596a3688d5bdc779e5a2e15e9d` | `7d2bd6dae6ff55dcb588fe155f6ba076e8b66fdedf0442c04810b241df4a5e26` | 157 | `testnet-treasury-unconfigured` |
| `conformance-web2-guard-a-39` | `01ad3dda2b032d46c94d8e2dc6fac17393af2c921cbaa7ca4e9ac76d51ee5f21` | `a85b6345c100cf1698639b761f101b4d1637a2bf40d39a99ecf9dece5ddd401e` | 437 | `testnet-treasury-unconfigured` |
| `conformance-wallet-transfer-a-to-b-40` | `17f8913249965518ba603e0fc85ad0e1218f422ea40a7c016f64ce5941656d5c` | `5ea0719a498e1abca426bece6c916f9e05e24bfa7f79b237865852ce16dcce50` | 200 | `testnet-treasury-unconfigured` |
| `conformance-exchange-sell-b-41` | `17269aa5585103beed5ee6d70eba18f313e6232fa81319bbbd22f7953ccdcc3f` | `62da09817a4c7948c809ddfe5407e7c3688888d7857241c20c20da5b30d01ef8` | 212 | `testnet-treasury-unconfigured` |
| `conformance-exchange-buy-a-42` | `543abaa35b3f31ec878b93d1d2e68667e8ba183045cb2399bd2cb65de966f891` | `6eeee500add9e3cdaa37ffba4b99c275f489d1c11dcbae958f1729532baee4c1` | 211 | `testnet-treasury-unconfigured` |
| `conformance-marketplace-publish-b-43` | `e90a7e5b779a654cb2f74fb737908d4e7fae2d88a294a076507ea9fc28523084` | `8db2f733232dc202dc6ec2040b53865d824d34b1a406a9ee4c578a4bb49f4271` | 186 | `testnet-treasury-unconfigured` |
| `conformance-marketplace-purchase-a-44` | `9de4aabac2df75e23302d2b3833e36ffff8c62e091cbfe74d2df402ef65b6245` | `4de90092d6abf0157a231b6e38d5f532efec592872681185f1f8674757f1baa4` | 189 | `testnet-treasury-unconfigured` |
| `conformance-airdrop-claim-a-trade_1-45` | `015272c3aa1da4c7433682a26f8a359ed299eb672e4d2426d74f1b4798711f73` | `7bee5c34cca3cad7d3ab2bb470330a84e840898675296668802a5c92e0c60ec9` | 162 | `testnet-treasury-unconfigured` |
| `conformance-airdrop-claim-a-store_1-46` | `11892cad8ec17ea0464d5d5e5a5ff39d7cfcd272db2a880eb3202f83a8e3da3f` | `6289648e8ac3cc152cbac8e4c885a50275a7a50d004299e307ad38533331e6a7` | 162 | `testnet-treasury-unconfigured` |
| `conformance-chat-dm-a-to-b-47` | `0479c148eec76e05a6749b113e3de8679d15f479b44d404f58bb8107b9a66a34` | `8a398c70880cdba5f6e41afa5ccde03fcea025e8db4d16a0f9aa10597172efbb` | 283 | `testnet-treasury-unconfigured` |
| `conformance-airdrop-claim-a-chat_1-48` | `8d103b692c99ebc01923a27e3cb3ff23c214597171006c6f19e589dc20035691` | `d001725de31488d53a04e7c204d86a37b077ba0ebe603f934f2f76cebce99105` | 161 | `testnet-treasury-unconfigured` |

## Proof export

- proof.zip (account A): `docs/evidence/20260208_191421_conformance/verify_all/proof_acct-48300cd76b430446.zip`
- sha256: `fa439c731772fde569624fa87e488cc0cc93ef78cdfa82df2755836ef6130fcd`
