# NYX verify_all PASS

- seed: 123
- run_id_base: extreme-testnet
- run_session: extreme-testnet-20260205_135727
- timestamp: 20260205_135727
- base_url: http://127.0.0.1:8091
- account_a: acct-48bbd5787d45220f (@aae0eb6e4)
- account_b: acct-e91a730a0ee10172 (@b3a164a7a)

Artifacts:
- verify log: `docs/evidence/20260205_135727_extreme-testnet/verify_all/verify.log`
- manifest: `docs/evidence/20260205_135727_extreme-testnet/verify_all/manifest.json`
- replay outputs: `docs/evidence/20260205_135727_extreme-testnet/verify_all/replay/`

## External integrations (read-only)

- 0x quote: status=200 (`docs/evidence/20260205_135727_extreme-testnet/verify_all/integration_0x_quote.json`)
- Jupiter quote: status=200 (`docs/evidence/20260205_135727_extreme-testnet/verify_all/integration_jupiter_quote.json`)
- Magic Eden collections: skipped
- Magic Eden listings: skipped
- Magic Eden token: skipped

## Runs (state mutations)

| run_id | state_hash | receipt_hash | fee_total | treasury |
|---|---|---|---:|---|
| `extreme-testnet-wallet-faucet-a-nyxt-111` | `25add8fcca70e6aa98802fe8e0f736c2299a6c9967bcab1639e93f3053fe5a3a` | `9564ef9e5102472d5376fc9b567febd507c0626cca1c0550c9e2d9f4d934b8bb` | 157 | `testnet-treasury-unconfigured` |
| `extreme-testnet-wallet-faucet-b-echo-112` | `00c08c624c1504172858321106ef45dd4d9dccf45434991840b5b448e4eeb22a` | `7fac7e4f4b23067ced75b52bee81981d82c552d10bf647c8f02ccb35049e242e` | 157 | `testnet-treasury-unconfigured` |
| `extreme-testnet-web2-guard-a-113` | `2b284019848525bfd3cbeedcf5d463bf5a3eb72c04bd1da5ab6094e4e5147b80` | `3dd29427ca6e66d96b7e1f880f72aed01d8ba835699d72d1fe23a1222e86d62f` | 436 | `testnet-treasury-unconfigured` |
| `extreme-testnet-wallet-transfer-a-to-b-114` | `6c471d6dc46bc754f1e144393b573771a4976621bad85b945f26ae507fc74bd6` | `7565e0dd2c3f0ef721ea5b79f3fc542b2744c34c14fbd5f4bc5937386bc1bbea` | 200 | `testnet-treasury-unconfigured` |
| `extreme-testnet-exchange-sell-b-115` | `ba516aefa8286656f1cac394161a0799771545e8104abd609735fd51c18ec0b7` | `757c1d79a530a9eae2be00f40ddeb788cd622785ba5aba98cc3926b6eca21b8a` | 212 | `testnet-treasury-unconfigured` |
| `extreme-testnet-exchange-buy-a-116` | `9a238bdc5e5f4967d3fd894e8a98390ffa4e935cfb80143edbc1a0fcfb529eb3` | `6284d13793e139ed70fddd31cfc7102431fc5eee6eb85d2a14871e65929c5ada` | 211 | `testnet-treasury-unconfigured` |
| `extreme-testnet-marketplace-publish-b-117` | `e8e8ff673c27881f0d29854422c1591ca192211b889d012faea7ef55f19cf158` | `6a377c9c503cb492d577ea5faacde545bde5f2f7b2487ccc77c6f429fba06cf3` | 186 | `testnet-treasury-unconfigured` |
| `extreme-testnet-marketplace-purchase-a-118` | `4a4cd855f5189ba258d098f9d34c0caa079326b76a0e868086d6f9f12b6a2af8` | `d62e4eec4119feba526696ba14cb04a6d5adbdfe1322ff1130eb0c2d84042a6b` | 189 | `testnet-treasury-unconfigured` |
| `extreme-testnet-airdrop-claim-a-trade_1-119` | `01ede58d9be9ee8e077001fa9db6c0881d9d02352c5f29f05e3d01dc9b21d1e8` | `dda97bb8a4d218708a3b9cf8dc449e8cc5e4cf545f1377bfa9364ee95df9fec4` | 216 | `testnet-treasury-unconfigured` |
| `extreme-testnet-airdrop-claim-a-store_1-120` | `69d15a14f90a9205374b42ae876a8d0b39fda2cf37955603c043431abd7371ae` | `8c4846f550bf1eb2273210ebce5ab1628f75f89ebbc8e30edb6a4c17d4fa5ce5` | 224 | `testnet-treasury-unconfigured` |
| `extreme-testnet-chat-dm-a-to-b-121` | `859a97c8ca592f2e1ec1137a934d4d12098ffea41f7135769d1744083af14c12` | `b3b41aa5dbdac288990334c316993b0368280e549ef5aacaddb091b1fff4b340` | 283 | `testnet-treasury-unconfigured` |
| `extreme-testnet-airdrop-claim-a-chat_1-122` | `cff03f6730b655fc27c7c795b9655c105b6239dba203df771dbd3891810b5aa3` | `fb83be1648078799019c7668b8676fc67703b319c03e94e444a0eb70a10daf25` | 215 | `testnet-treasury-unconfigured` |

## Proof export

- proof.zip (account A): `docs/evidence/20260205_135727_extreme-testnet/verify_all/proof_acct-48bbd5787d45220f.zip`
- sha256: `f39be5cb51cfdd4733350f06b198f94b388721a5263d8401841ae07af90ccfeb`
