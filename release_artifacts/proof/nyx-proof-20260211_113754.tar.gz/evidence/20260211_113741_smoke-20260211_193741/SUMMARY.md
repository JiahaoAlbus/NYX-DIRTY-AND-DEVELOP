# NYX verify_all PASS

- seed: 123
- run_id_base: smoke-20260211_193741
- run_session: smoke-20260211_193741-20260211_113741
- timestamp: 20260211_113741
- base_url: http://127.0.0.1:8091
- account_a: acct-981f6910cf194465 (@a515fb794)
- account_b: acct-02cefa0baf8234cd (@b355254e3)

Artifacts:
- verify log: `docs/evidence/20260211_113741_smoke-20260211_193741/verify_all/verify.log`
- manifest: `docs/evidence/20260211_113741_smoke-20260211_193741/verify_all/manifest.json`
- replay outputs: `docs/evidence/20260211_113741_smoke-20260211_193741/verify_all/replay/`

## External integrations (read-only)

- 0x quote: status=200 (`docs/evidence/20260211_113741_smoke-20260211_193741/verify_all/integration_0x_quote.json`)
- Jupiter quote: status=200 (`docs/evidence/20260211_113741_smoke-20260211_193741/verify_all/integration_jupiter_quote.json`)
- Magic Eden collections: status=200 (`docs/evidence/20260211_113741_smoke-20260211_193741/verify_all/integration_magic_eden_collections.json`)
- Magic Eden listings: status=200 (`docs/evidence/20260211_113741_smoke-20260211_193741/verify_all/integration_magic_eden_listings.json`)
- Magic Eden token: skipped

## Runs (state mutations)

| run_id | state_hash | receipt_hash | fee_total | treasury |
|---|---|---|---:|---|
| `smoke-20260211_193741-wallet-faucet-a-nyxt-1` | `481ae2c048e3bfdadcfb61f0b845393acdf6419f999e3a28f662a4709960faea` | `445e6232a6ef4d91e7141ceaee298b4aefc4360c557aa556913f8568cc6e6f6f` | 159 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193741-wallet-faucet-b-echo-2` | `e29de5ffa76555d0f6b5139f776256eba367abddbca23e94b4e528a72ac233ce` | `b7265e616d68ff8aacf0e3420ba230dbeccb9b419984b918cbdf099e918ab68e` | 159 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193741-web2-guard-a-3` | `7ca8e8873ae3668ddebf03fa966f4b9998b1f12e04763cf73f56b09945f2de90` | `937e5f5ea2a940c3246e44032ae9f083af4dd2c749d4dd7598a000155be69f67` | 437 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193741-wallet-transfer-a-to-b-4` | `d1e32d5f105624c364f416779d754e4851b8b4cbe13857b15ef06f0c45b2c024` | `4ba796763c815a25b609bc3d119eb4763df60dd40d73dbb426278feab6a0a740` | 205 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193741-exchange-sell-b-5` | `b16b8bdcd71d669839171c47dcfbdbd6200a99754dbe6d92999e3fe69276c5b9` | `a5db12cdf904d7620f4726f45f791e669bd88003815321b82aa1f2f5d999560e` | 214 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193741-exchange-buy-a-6` | `27fcfdbd2611c6421781d175bfd47a56bef98dbce2e8e403239c209422ac936a` | `9f9af81b0727b52d3abcb9ec099033efd7b9c3a09f537c41625cc3bfc361f31d` | 213 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193741-marketplace-publish-b-7` | `908fcc2ecbafd6c49998be705785db70843e0ef2dc51c793538afb67ce8edc66` | `22dff4152d2faa66fdb1022c738b43c12942250fa3c46c909511c80e21354732` | 188 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193741-marketplace-purchase-a-8` | `dd56e15622515760053e8b8eb3a7f4e0e65bf40bd418d98bcbebe08eb4601a09` | `1ca2eab9dc20f1fe8a2d0c2a07f21721ca5cc7cb36680d392089e697099af1bd` | 191 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193741-airdrop-claim-a-trade_1-9` | `501e72d14edd516d7e26f339cebb3945925c9818ba998d603fc7f734467cfa15` | `0d98c0440b40a44efac53dd61cf73c0a2c52505ffc1cb5de7f7d29b24d55ebb7` | 205 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193741-airdrop-claim-a-store_1-10` | `a2fe701d44933f96c227ef7e8f725c2c35c24bb84f630e4ecae222c711a53bbe` | `decf23026395cc1d8ca6f1dbd7a38b77823198a5e35c0b547b4c292f72a90cfd` | 205 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193741-chat-dm-a-to-b-11` | `18aba0a36ac7df4654326e6e4b6a5a531ecf812476aa219b9d15250d80986a12` | `0a94a256420317ccf16eda7dc8c2e01d8645466a344f70ddb8e398b0e3c6f111` | 283 | `testnet-treasury-unconfigured` |
| `smoke-20260211_193741-airdrop-claim-a-chat_1-12` | `758e5c87f2f85757cd426e4eb0e1b77c356ec494fccbbd0e147a36dfb29218fe` | `cae63e985978661558d6caf20a1831bf0dfb97df3fbdff60bca6dd5a1a5aef97` | 204 | `testnet-treasury-unconfigured` |

## Proof export

- proof.zip (account A): `docs/evidence/20260211_113741_smoke-20260211_193741/verify_all/proof_acct-981f6910cf194465.zip`
- sha256: `0c60551378bca66408f85dfd9809600c9b62d4fc9d031fcc36f81ec006effd8d`
