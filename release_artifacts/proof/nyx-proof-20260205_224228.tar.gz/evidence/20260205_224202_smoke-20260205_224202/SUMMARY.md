# NYX verify_all PASS

- seed: 123
- run_id_base: smoke-20260205_224202
- run_session: smoke-20260205_224202-20260205_224202
- timestamp: 20260205_224202
- base_url: http://127.0.0.1:8091
- account_a: acct-d037a2a89455f336 (@a73d7ecc1)
- account_b: acct-0dc17c5a6c3bd87a (@bcf711e91)

Artifacts:
- verify log: `docs/evidence/20260205_224202_smoke-20260205_224202/verify_all/verify.log`
- manifest: `docs/evidence/20260205_224202_smoke-20260205_224202/verify_all/manifest.json`
- replay outputs: `docs/evidence/20260205_224202_smoke-20260205_224202/verify_all/replay/`

## External integrations (read-only)

- 0x quote: status=200 (`docs/evidence/20260205_224202_smoke-20260205_224202/verify_all/integration_0x_quote.json`)
- Jupiter quote: status=200 (`docs/evidence/20260205_224202_smoke-20260205_224202/verify_all/integration_jupiter_quote.json`)
- Magic Eden collections: status=200 (`docs/evidence/20260205_224202_smoke-20260205_224202/verify_all/integration_magic_eden_collections.json`)
- Magic Eden listings: status=200 (`docs/evidence/20260205_224202_smoke-20260205_224202/verify_all/integration_magic_eden_listings.json`)
- Magic Eden token: skipped

## Runs (state mutations)

| run_id | state_hash | receipt_hash | fee_total | treasury |
|---|---|---|---:|---|
| `smoke-20260205_224202-wallet-faucet-a-nyxt-1` | `399295f91664f686f64492bff3910247f5410f1a496bcf0e724aaed1cc5cfb14` | `f1a20c3385acb3f74314015fcc9b8a2adb83395c12889a7228c69df543e9b100` | 157 | `testnet-treasury-unconfigured` |
| `smoke-20260205_224202-wallet-faucet-b-echo-2` | `e9673bdf152e2625bafe59da58305e806996e48ad6de1cbdbfc65c412be10fa5` | `1feec31b09e6eb99dfdb9f3f070763c302637dcfc93cc52bf13d81986659f3cf` | 157 | `testnet-treasury-unconfigured` |
| `smoke-20260205_224202-web2-guard-a-3` | `94fd61dd26e67bd8a88311833d5b2986812d739b1a71ad8d730d33fb082dbfb6` | `1ad3afabf7a8d8861a769a9ae593da803b9519311c44b40584d7522ec901f879` | 436 | `testnet-treasury-unconfigured` |
| `smoke-20260205_224202-wallet-transfer-a-to-b-4` | `783ea1d4f8f776f5335b74abf5f24c562863ccd5c3cdf00ee59b4b6b73636661` | `d2aed428ccb60175c2e8d910867c3ed629ecdea6174256ca8b0f8f7c28ad55d4` | 200 | `testnet-treasury-unconfigured` |
| `smoke-20260205_224202-exchange-sell-b-5` | `57fc89845281fd6568010f75bae2f7119fe1aa7f749e75bac8775890da8a823a` | `3000ad6382064e8d7efca37d2970635c0256d7de40714d073e0aebdda7b46fc5` | 212 | `testnet-treasury-unconfigured` |
| `smoke-20260205_224202-exchange-buy-a-6` | `42860ed0eeb700bf3cbaf45bbb3baeae8899cf75c62ca2fcea14983f291ab836` | `c7a323304250d3326102c69b255bc948c7fb1921efdd42c03cb031f77b67b40f` | 211 | `testnet-treasury-unconfigured` |
| `smoke-20260205_224202-marketplace-publish-b-7` | `74e3a6759368d07579fb65955468162e8b77996a30e39bc81748a953e790d5e7` | `40c8ef11ae035129960cedcd356538d5e95ad5672721211914a45131b06d6ab7` | 186 | `testnet-treasury-unconfigured` |
| `smoke-20260205_224202-marketplace-purchase-a-8` | `690d32c5be2c4f50129eec0b5550d54a58d30b28a6043dfe255995fe95fa64dd` | `489b2a38452d36bc6fd0a0d639d6a410b014e19357e11d2ae8b4b7b8030f56ef` | 189 | `testnet-treasury-unconfigured` |
| `smoke-20260205_224202-airdrop-claim-a-trade_1-9` | `b5e1d58d8c57c358a6b00a38ab953eba141313f8dacd19a4e7ed4f2de12800b4` | `d6e38104e1251f6ae96dabb1a2ce55bbd14e29e5eb934d2acfe31734d7cf2df7` | 220 | `testnet-treasury-unconfigured` |
| `smoke-20260205_224202-airdrop-claim-a-store_1-10` | `a0f2e88a2edfecf6827805c4adc0d93309070eae29d3c8d18cea312b0cf4e410` | `853c955839144b329c42c1cc6d976050305b7ab106f9e194bc73d97e48f22137` | 228 | `testnet-treasury-unconfigured` |
| `smoke-20260205_224202-chat-dm-a-to-b-11` | `97db354723f026e5e53b14845d0c1b53868fc0587fd30129739a001f6392a1a8` | `709ed23e1d60225b0ae15a2f2610e89af6e50b1c17fc61adcd01bdb440c16d2b` | 283 | `testnet-treasury-unconfigured` |
| `smoke-20260205_224202-airdrop-claim-a-chat_1-12` | `5948c5c188eed8f8e2f3a501f0df5d0be6735ecb84516fd5a2977055e488c0e1` | `c5fe2b9f3fc1f7e4090327e64336bd357a516ff858f32620eccb7fc4aebd527d` | 220 | `testnet-treasury-unconfigured` |

## Proof export

- proof.zip (account A): `docs/evidence/20260205_224202_smoke-20260205_224202/verify_all/proof_acct-d037a2a89455f336.zip`
- sha256: `3d153383ed8f30aaa5c4ac3f17f519a9a2fa976cb08ea92be540ebdd57643e7a`
